export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
}

export interface Team {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  leaderId: string;
  members: string[];
  color: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  teamId: string;
  assignedTo: string;
  assignedBy: string;
  status: 'pending-acceptance' | 'in-progress' | 'completed' | 'dropped';
  deadline: string;
  createdAt: string;
  acceptedAt?: string;
}

export interface Reminder {
  id: string;
  name: string;
  taskId: string;
  taskTitle: string;
  teamId: string;
  sound: string;
  interval: string;
  alertTime: string;
  enabled: boolean;
  nextAlert: string;
}

export interface ChatMessage {
  id: string;
  teamId: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: string;
  isTaskAssignment?: boolean;
  taskId?: string;
}

export interface Document {
  id: string;
  teamId: string;
  name: string;
  label: string;
  uploadedBy: string;
  uploadedAt: string;
  url: string;
  type: string;
}

export interface SubmissionLink {
  id: string;
  teamId: string;
  title: string;
  url: string;
  expiresAt: string;
}

export interface JoinRequest {
  id: string;
  teamId: string;
  requesterId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}
