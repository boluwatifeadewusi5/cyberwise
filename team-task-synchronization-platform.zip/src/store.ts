import { create } from 'zustand';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import type { User, Team, Task, Reminder, ChatMessage, Document, SubmissionLink, JoinRequest } from './types';

const LOCAL_AUTH_USERS_KEY = 'micah_auth_users';
const LOCAL_ACTIVE_USER_KEY = 'micah_active_user';
const LOCAL_WORKSPACE_PREFIX = 'micah_workspace_';

type LocalAuthUser = User & { password: string };

const CURRENT_USER: User = {
  id: 'user-1',
  name: 'Alex Johnson',
  email: 'alex@university.edu',
  avatar: 'AJ',
};

const MOCK_USERS: User[] = [
  CURRENT_USER,
  { id: 'user-2', name: 'Sarah Chen', email: 'sarah@university.edu', avatar: 'SC' },
  { id: 'user-3', name: 'Marcus Williams', email: 'marcus@university.edu', avatar: 'MW' },
  { id: 'user-4', name: 'Priya Patel', email: 'priya@university.edu', avatar: 'PP' },
  { id: 'user-5', name: 'James Rivera', email: 'james@university.edu', avatar: 'JR' },
];

const TEST_PROFILES: User[] = [
  { id: 'fake-user-101', name: 'Nina Brooks', email: 'nina.brooks+micah@testmail.dev', avatar: 'NB' },
  { id: 'fake-user-102', name: 'Owen Clarke', email: 'owen.clarke+micah@testmail.dev', avatar: 'OC' },
  { id: 'fake-user-103', name: 'Lila Hammond', email: 'lila.hammond+micah@testmail.dev', avatar: 'LH' },
  { id: 'fake-user-104', name: 'Diego Romero', email: 'diego.romero+micah@testmail.dev', avatar: 'DR' },
  { id: 'fake-user-105', name: 'Farah Malik', email: 'farah.malik+micah@testmail.dev', avatar: 'FM' },
];

const MOCK_TEAMS: Team[] = [
  {
    id: 'team-1',
    name: 'Capstone Project Alpha',
    description: 'Final year capstone project - building a health tracking mobile app with React Native and Firebase.',
    createdBy: 'user-1',
    leaderId: 'user-1',
    members: ['user-1', 'user-2', 'user-3'],
    color: '#3B82F6',
  },
  {
    id: 'team-2',
    name: 'HCI Research Group',
    description: 'Human-Computer Interaction research team working on accessibility audits and usability testing.',
    createdBy: 'user-2',
    leaderId: 'user-2',
    members: ['user-1', 'user-2', 'user-4', 'user-5'],
    color: '#F97316',
  },
  {
    id: 'team-3',
    name: 'Database Systems Lab',
    description: 'Collaborative lab group for DBMS coursework - normalization, ER diagrams, and query optimization.',
    createdBy: 'user-3',
    leaderId: 'user-3',
    members: ['user-1', 'user-3', 'user-5'],
    color: '#6366F1',
  },
];

const MOCK_TASKS: Task[] = [
  {
    id: 'task-1',
    title: 'Design user persona document',
    description: 'Create 3 detailed user personas for the health tracking app target audience.',
    teamId: 'team-1',
    assignedTo: 'user-1',
    assignedBy: 'user-2',
    status: 'in-progress',
    deadline: '2026-02-15',
    createdAt: '2026-01-20T10:00:00Z',
  },
  {
    id: 'task-3',
    title: 'Conduct accessibility audit',
    description: 'Run WCAG 2.1 AA audit on the university library portal.',
    teamId: 'team-2',
    assignedTo: 'user-1',
    assignedBy: 'user-4',
    status: 'in-progress',
    deadline: '2026-02-20',
    createdAt: '2026-01-22T09:00:00Z',
  },
  {
    id: 'task-4',
    title: 'Write ER diagram report',
    description: 'Document the ER diagram with cardinality ratios and participation constraints.',
    teamId: 'team-3',
    assignedTo: 'user-1',
    assignedBy: 'user-3',
    status: 'completed',
    deadline: '2026-01-30',
    createdAt: '2026-01-15T14:00:00Z',
  },
  {
    id: 'task-5',
    title: 'Prepare usability test script',
    description: 'Draft a moderated usability test script with 10 tasks and follow-up questions.',
    teamId: 'team-2',
    assignedTo: 'user-1',
    assignedBy: 'user-2',
    status: 'pending-acceptance',
    deadline: '2026-02-25',
    createdAt: '2026-01-28T16:00:00Z',
  },
];

const MOCK_REMINDERS: Reminder[] = [
  {
    id: 'rem-1',
    name: 'Persona daily check',
    taskId: 'task-1',
    taskTitle: 'Design user persona document',
    teamId: 'team-1',
    sound: 'chime',
    interval: 'daily',
    alertTime: '09:00',
    enabled: true,
    nextAlert: '2026-02-01T09:00:00Z',
  },
  {
    id: 'rem-2',
    name: 'Audit weekly review',
    taskId: 'task-3',
    taskTitle: 'Conduct accessibility audit',
    teamId: 'team-2',
    sound: 'bell',
    interval: 'weekly',
    alertTime: '10:00',
    enabled: true,
    nextAlert: '2026-02-03T10:00:00Z',
  },
];

const MOCK_MESSAGES: ChatMessage[] = [
  { id: 'msg-1', teamId: 'team-1', senderId: 'user-2', senderName: 'Sarah Chen', content: 'Hey team! Let\'s finalize the sprint plan today.', timestamp: '2026-01-28T09:00:00Z' },
  { id: 'msg-2', teamId: 'team-1', senderId: 'user-1', senderName: 'Alex Johnson', content: 'Sounds good! I\'ve started on the user personas already.', timestamp: '2026-01-28T09:05:00Z' },
  { id: 'msg-3', teamId: 'team-2', senderId: 'user-4', senderName: 'Priya Patel', content: 'The accessibility audit template is uploaded in the docs section.', timestamp: '2026-01-28T10:00:00Z' },
];

const MOCK_DOCUMENTS: Document[] = [
  { id: 'doc-1', teamId: 'team-1', name: 'User Personas v1.pdf', label: 'User Personas', uploadedBy: 'user-1', uploadedAt: '2026-01-22T10:00:00Z', url: '#', type: 'pdf' },
  { id: 'doc-2', teamId: 'team-2', name: 'WCAG Checklist.xlsx', label: 'Research Data', uploadedBy: 'user-4', uploadedAt: '2026-01-23T11:00:00Z', url: '#', type: 'spreadsheet' },
];

const MOCK_SUBMISSION_LINKS: SubmissionLink[] = [
  { id: 'sub-1', teamId: 'team-1', title: 'Capstone Midterm Submission', url: 'https://university.edu/submit/capstone', expiresAt: '2026-03-01T23:59:00Z' },
];

interface WorkspaceData {
  allUsers: User[];
  teams: Team[];
  allTeams: Team[];
  joinRequests: JoinRequest[];
  tasks: Task[];
  reminders: Reminder[];
  messages: ChatMessage[];
  documents: Document[];
  submissionLinks: SubmissionLink[];
}

interface AppState extends WorkspaceData {
  currentUser: User;
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  isBootstrapped: boolean;
  authError: string | null;

  initializeApp: () => Promise<void>;
  initLiveChat: () => void;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;

  createTeam: (name: string, description: string, memberIds?: string[]) => void;
  addMembersToTeam: (teamId: string, memberIds: string[]) => void;
  searchTeams: (query: string) => Promise<Team[]>;
  requestJoinTeam: (teamId: string) => Promise<{ ok: boolean; message: string }>;
  reviewJoinRequest: (requestId: string, decision: 'accepted' | 'rejected') => Promise<void>;
  deleteTeam: (teamId: string) => void;
  leaveTeam: (teamId: string) => void;

  findUsers: (query: string) => Promise<User[]>;
  seedTestProfiles: () => void;

  addTask: (title: string, description: string, teamId: string, assignedTo: string, deadline: string) => Task;
  acceptTask: (taskId: string) => void;
  dropTask: (taskId: string) => void;
  completeTask: (taskId: string) => void;

  addReminder: (name: string, taskId: string, taskTitle: string, teamId: string, sound: string, interval: string, alertTime: string) => void;
  deleteReminder: (reminderId: string) => void;
  toggleReminder: (reminderId: string) => void;
  updateReminder: (reminderId: string, updates: Partial<Pick<Reminder, 'name' | 'sound' | 'interval' | 'alertTime' | 'enabled'>>) => void;
  updateReminderSound: (reminderId: string, sound: string) => void;

  sendMessage: (teamId: string, content: string, isTaskAssignment?: boolean, taskId?: string) => void;

  addDocument: (teamId: string, name: string, label: string, type: string, url?: string) => void;

  addSubmissionLink: (teamId: string, title: string, url: string, expiresAt: string) => void;

  getUserById: (id: string) => User | undefined;
  getTeamById: (id: string) => Team | undefined;
  getTasksForUser: () => Task[];
  getTasksForTeam: (teamId: string) => Task[];
  getMessagesForTeam: (teamId: string) => ChatMessage[];
  getDocumentsForTeam: (teamId: string) => Document[];
  getSubmissionLinksForTeam: (teamId: string) => SubmissionLink[];
}

const loadJson = <T>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
};

const saveJson = (key: string, value: unknown) => {
  localStorage.setItem(key, JSON.stringify(value));
};

const getInitialWorkspace = (user: User): WorkspaceData => {
  if (user.id === CURRENT_USER.id) {
    return {
      allUsers: MOCK_USERS,
      teams: MOCK_TEAMS,
      allTeams: MOCK_TEAMS,
      joinRequests: [],
      tasks: MOCK_TASKS,
      reminders: MOCK_REMINDERS,
      messages: MOCK_MESSAGES,
      documents: MOCK_DOCUMENTS,
      submissionLinks: MOCK_SUBMISSION_LINKS,
    };
  }

  return {
    // New accounts start with only real known users and discover others via profile search.
    allUsers: [user],
    teams: [],
    allTeams: [],
    joinRequests: [],
    tasks: [],
    reminders: [],
    messages: [],
    documents: [],
    submissionLinks: [],
  };
};

const getWorkspaceKey = (userId: string) => `${LOCAL_WORKSPACE_PREFIX}${userId}`;

const loadLocalWorkspace = (user: User): WorkspaceData => {
  const workspace = loadJson<WorkspaceData | null>(getWorkspaceKey(user.id), null);
  if (workspace) {
    return {
      ...workspace,
      allTeams: workspace.allTeams && workspace.allTeams.length > 0 ? workspace.allTeams : workspace.teams,
      joinRequests: workspace.joinRequests || [],
    };
  }
  return getInitialWorkspace(user);
};

const getNextAlertIso = (time: string, interval: string): string => {
  const [hours, minutes] = time.split(':').map(Number);
  const next = new Date();
  next.setSeconds(0, 0);
  next.setHours(hours, minutes, 0, 0);

  while (next.getTime() <= Date.now()) {
    if (interval === 'hourly') {
      next.setHours(next.getHours() + 1);
    } else if (interval === 'every-2-hours') {
      next.setHours(next.getHours() + 2);
    } else if (interval === 'every-2-days') {
      next.setDate(next.getDate() + 2);
    } else if (interval === 'weekly') {
      next.setDate(next.getDate() + 7);
    } else {
      next.setDate(next.getDate() + 1);
    }
  }

  return next.toISOString();
};

const toWorkspace = (state: AppState): WorkspaceData => ({
  allUsers: state.allUsers,
  teams: state.teams,
  allTeams: state.allTeams,
  joinRequests: state.joinRequests,
  tasks: state.tasks,
  reminders: state.reminders,
  messages: state.messages,
  documents: state.documents,
  submissionLinks: state.submissionLinks,
});

const saveRemoteWorkspace = async (userId: string, workspace: WorkspaceData) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase.from('micah_workspaces').upsert(
      { user_id: userId, payload: workspace, updated_at: new Date().toISOString() },
      { onConflict: 'user_id' }
    );
  } catch {
    // Keep app usable even if remote table is not created yet.
  }
};

const upsertRemoteProfile = async (user: User) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase.from('micah_profiles').upsert(
      {
        id: user.id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );
  } catch {
    // Keep auth flow working even if the table is not available yet.
  }
};

const loadRemoteProfiles = async (): Promise<User[] | null> => {
  if (!isSupabaseConfigured || !supabase) return null;
  try {
    const { data, error } = await supabase.from('micah_profiles').select('id,name,email,avatar');
    if (error || !data) return null;
    return data as User[];
  } catch {
    return null;
  }
};

const searchRemoteProfiles = async (query: string): Promise<User[]> => {
  if (!isSupabaseConfigured || !supabase) return [];

  const trimmed = query.trim();

  try {
    const baseQuery = supabase
      .from('micah_profiles')
      .select('id,name,email,avatar')
      .limit(30);

    const { data, error } = trimmed
      ? await baseQuery.or(`name.ilike.%${trimmed}%,email.ilike.%${trimmed}%`)
      : await baseQuery.order('updated_at', { ascending: false });

    if (error || !data) return [];
    return data as User[];
  } catch {
    return [];
  }
};

const saveRemoteMessage = async (message: ChatMessage) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase.from('micah_messages').insert({
      id: message.id,
      team_id: message.teamId,
      sender_id: message.senderId,
      sender_name: message.senderName,
      content: message.content,
      timestamp: message.timestamp,
      is_task_assignment: Boolean(message.isTaskAssignment),
      task_id: message.taskId ?? null,
    });
  } catch {
    // Broadcast fallback keeps the chat interactive when DB write fails.
  }
};

const loadRemoteMessages = async (teamIds: string[]): Promise<ChatMessage[]> => {
  if (!isSupabaseConfigured || !supabase || teamIds.length === 0) return [];
  try {
    const { data, error } = await supabase
      .from('micah_messages')
      .select('id,team_id,sender_id,sender_name,content,timestamp,is_task_assignment,task_id')
      .in('team_id', teamIds)
      .order('timestamp', { ascending: true })
      .limit(500);

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id as string,
      teamId: row.team_id as string,
      senderId: row.sender_id as string,
      senderName: row.sender_name as string,
      content: row.content as string,
      timestamp: row.timestamp as string,
      isTaskAssignment: Boolean(row.is_task_assignment),
      taskId: (row.task_id as string | null) ?? undefined,
    }));
  } catch {
    return [];
  }
};

const loadRemoteWorkspace = async (userId: string): Promise<WorkspaceData | null> => {
  if (!isSupabaseConfigured || !supabase) return null;
  try {
    const { data, error } = await supabase
      .from('micah_workspaces')
      .select('payload')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data?.payload) return null;
    const payload = data.payload as Partial<WorkspaceData>;
    return {
      allUsers: payload.allUsers || [],
      teams: payload.teams || [],
      allTeams: payload.allTeams && payload.allTeams.length > 0 ? payload.allTeams : payload.teams || [],
      joinRequests: payload.joinRequests || [],
      tasks: payload.tasks || [],
      reminders: payload.reminders || [],
      messages: payload.messages || [],
      documents: payload.documents || [],
      submissionLinks: payload.submissionLinks || [],
    };
  } catch {
    return null;
  }
};

const createRemoteTeam = async (team: Team) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase.from('micah_teams').upsert(
      {
        id: team.id,
        name: team.name,
        description: team.description,
        created_by: team.createdBy,
        leader_id: team.leaderId,
        color: team.color,
      },
      { onConflict: 'id' }
    );

    await supabase.from('micah_team_members').upsert(
      team.members.map((memberId) => ({ team_id: team.id, user_id: memberId })),
      { onConflict: 'team_id,user_id' }
    );
  } catch {
    // Local fallback keeps team creation usable if remote tables are missing.
  }
};

const addRemoteTeamMembers = async (teamId: string, memberIds: string[]) => {
  if (!isSupabaseConfigured || !supabase || memberIds.length === 0) return;
  try {
    await supabase.from('micah_team_members').upsert(
      memberIds.map((memberId) => ({ team_id: teamId, user_id: memberId })),
      { onConflict: 'team_id,user_id' }
    );
  } catch {
    // Keep local behavior active even if remote write fails.
  }
};

const loadRemoteTeamsForUser = async (userId: string): Promise<Team[]> => {
  if (!isSupabaseConfigured || !supabase) return [];
  try {
    const { data: memberships, error: memberError } = await supabase
      .from('micah_team_members')
      .select('team_id')
      .eq('user_id', userId);

    if (memberError || !memberships || memberships.length === 0) return [];
    const teamIds = Array.from(new Set(memberships.map((row) => row.team_id as string)));

    const [{ data: teamsData, error: teamsError }, { data: allMembers, error: membersError }] = await Promise.all([
      supabase.from('micah_teams').select('id,name,description,created_by,leader_id,color').in('id', teamIds),
      supabase.from('micah_team_members').select('team_id,user_id').in('team_id', teamIds),
    ]);

    if (teamsError || membersError || !teamsData || !allMembers) return [];

    return teamsData.map((row) => ({
      id: row.id as string,
      name: row.name as string,
      description: row.description as string,
      createdBy: row.created_by as string,
      leaderId: row.leader_id as string,
      color: (row.color as string) || '#3B82F6',
      members: allMembers
        .filter((memberRow) => memberRow.team_id === row.id)
        .map((memberRow) => memberRow.user_id as string),
    }));
  } catch {
    return [];
  }
};

const searchRemoteTeams = async (query: string): Promise<Team[]> => {
  if (!isSupabaseConfigured || !supabase) return [];
  const trimmed = query.trim();

  try {
    const teamQuery = supabase
      .from('micah_teams')
      .select('id,name,description,created_by,leader_id,color')
      .limit(50);

    const { data: teamsData, error } = trimmed
      ? await teamQuery.or(`name.ilike.%${trimmed}%,description.ilike.%${trimmed}%`)
      : await teamQuery.order('name', { ascending: true });

    if (error || !teamsData || teamsData.length === 0) return [];

    const teamIds = teamsData.map((row) => row.id as string);
    const { data: allMembers, error: memberError } = await supabase
      .from('micah_team_members')
      .select('team_id,user_id')
      .in('team_id', teamIds);

    if (memberError || !allMembers) return [];

    return teamsData.map((row) => ({
      id: row.id as string,
      name: row.name as string,
      description: row.description as string,
      createdBy: row.created_by as string,
      leaderId: row.leader_id as string,
      color: (row.color as string) || '#3B82F6',
      members: allMembers
        .filter((memberRow) => memberRow.team_id === row.id)
        .map((memberRow) => memberRow.user_id as string),
    }));
  } catch {
    return [];
  }
};

const loadRemoteJoinRequestsForLeader = async (leaderId: string): Promise<JoinRequest[]> => {
  if (!isSupabaseConfigured || !supabase) return [];
  try {
    const { data: ownedTeams, error: teamsError } = await supabase
      .from('micah_teams')
      .select('id')
      .eq('leader_id', leaderId);
    if (teamsError || !ownedTeams || ownedTeams.length === 0) return [];
    const teamIds = ownedTeams.map((team) => team.id as string);

    const { data, error } = await supabase
      .from('micah_join_requests')
      .select('id,team_id,requester_id,status,created_at,reviewed_at,reviewed_by')
      .in('team_id', teamIds)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id as string,
      teamId: row.team_id as string,
      requesterId: row.requester_id as string,
      status: row.status as JoinRequest['status'],
      createdAt: row.created_at as string,
      reviewedAt: (row.reviewed_at as string | null) ?? undefined,
      reviewedBy: (row.reviewed_by as string | null) ?? undefined,
    }));
  } catch {
    return [];
  }
};

const createRemoteJoinRequest = async (request: JoinRequest) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase.from('micah_join_requests').insert({
      id: request.id,
      team_id: request.teamId,
      requester_id: request.requesterId,
      status: request.status,
      created_at: request.createdAt,
    });
  } catch {
    // Local fallback still allows request flow in non-cloud mode.
  }
};

const updateRemoteJoinRequest = async (
  requestId: string,
  payload: { status: 'accepted' | 'rejected'; reviewedBy: string; reviewedAt: string }
) => {
  if (!isSupabaseConfigured || !supabase) return;
  try {
    await supabase
      .from('micah_join_requests')
      .update({ status: payload.status, reviewed_by: payload.reviewedBy, reviewed_at: payload.reviewedAt })
      .eq('id', requestId);
  } catch {
    // Keep local behavior active even when cloud update fails.
  }
};

const mergeTeams = (baseTeams: Team[], incomingTeams: Team[]): Team[] => {
  const merged = new Map<string, Team>();
  baseTeams.forEach((team) => merged.set(team.id, team));
  incomingTeams.forEach((team) => {
    const existing = merged.get(team.id);
    if (!existing) {
      merged.set(team.id, team);
      return;
    }

    merged.set(team.id, {
      ...existing,
      ...team,
      members: Array.from(new Set([...existing.members, ...team.members])),
    });
  });
  return Array.from(merged.values());
};

let browserChannel: BroadcastChannel | null = null;
let browserChannelBound = false;
let supabaseBroadcastChannel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;
let supabaseDbChannel: ReturnType<NonNullable<typeof supabase>['channel']> | null = null;
let fakeChatIntervalId: number | null = null;
let fakeChatIntervalOwnerId: string | null = null;
let fakeTaskResponseTimers = new Map<string, number>();

type StoreSet = (fn: (state: AppState) => AppState | Partial<AppState>) => void;
type StoreGet = () => AppState;

const FAKE_CHAT_LINES = [
  'I reviewed the latest updates. Looks good from my side.',
  'Quick check-in: I can take another task if needed.',
  'I uploaded my progress notes and will keep iterating.',
  'Can we align on deadline priorities for the next checkpoint?',
  'I am online now and ready to help unblock anything pending.',
];

const isFakeProfile = (userId: string) => userId.startsWith('fake-user-');

const buildChatMessage = (
  teamId: string,
  sender: User,
  content: string,
  isTaskAssignment = false,
  taskId?: string
): ChatMessage => ({
  id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
  teamId,
  senderId: sender.id,
  senderName: sender.name,
  content,
  timestamp: new Date().toISOString(),
  isTaskAssignment,
  taskId,
});

const publishMessage = (set: StoreSet, get: StoreGet, message: ChatMessage) => {
  set((state) => {
    if (state.messages.some((existing) => existing.id === message.id)) return state;
    return { messages: [...state.messages, message] };
  });

  if (browserChannel) {
    browserChannel.postMessage(message);
  }

  if (supabaseBroadcastChannel) {
    void supabaseBroadcastChannel.send({ type: 'broadcast', event: 'new-message', payload: message });
  }

  void saveRemoteMessage(message);
  persistWorkspace(get);
};

const startFakeChatLoop = (set: StoreSet, get: StoreGet) => {
  if (typeof window === 'undefined') return;

  const ownerId = get().currentUser.id;
  if (fakeChatIntervalId && fakeChatIntervalOwnerId === ownerId) return;

  if (fakeChatIntervalId) {
    window.clearInterval(fakeChatIntervalId);
    fakeChatIntervalId = null;
  }

  fakeChatIntervalOwnerId = ownerId;
  fakeChatIntervalId = window.setInterval(() => {
    const state = get();
    if (!state.isAuthenticated) return;

    const candidateTeams = state.teams.filter(
      (team) => team.members.includes(state.currentUser.id) && team.members.some((memberId) => isFakeProfile(memberId))
    );

    if (candidateTeams.length === 0) return;
    if (Math.random() < 0.6) return;

    const targetTeam = candidateTeams[Math.floor(Math.random() * candidateTeams.length)];
    const fakeMemberIds = targetTeam.members.filter((memberId) => isFakeProfile(memberId));
    if (fakeMemberIds.length === 0) return;

    const fakeUser = state.allUsers.find((user) => user.id === fakeMemberIds[Math.floor(Math.random() * fakeMemberIds.length)]);
    if (!fakeUser) return;

    const line = FAKE_CHAT_LINES[Math.floor(Math.random() * FAKE_CHAT_LINES.length)];
    const autoReply = buildChatMessage(targetTeam.id, fakeUser, line);
    publishMessage(set, get, autoReply);
  }, 28000);
};

const scheduleFakeTaskResponse = (set: StoreSet, get: StoreGet, taskId: string) => {
  if (typeof window === 'undefined') return;
  if (fakeTaskResponseTimers.has(taskId)) return;

  const delay = 15000 + Math.floor(Math.random() * 20000);
  const timerId = window.setTimeout(() => {
    fakeTaskResponseTimers.delete(taskId);

    const state = get();
    const task = state.tasks.find((entry) => entry.id === taskId);
    if (!task || task.status !== 'pending-acceptance' || !isFakeProfile(task.assignedTo)) return;

    get().acceptTask(task.id);

    const responder = get().allUsers.find((user) => user.id === task.assignedTo);
    if (!responder) return;

    const response = buildChatMessage(task.teamId, responder, `I accepted "${task.title}" and will start now.`);
    publishMessage(set, get, response);
  }, delay);

  fakeTaskResponseTimers.set(taskId, timerId);
};

const persistWorkspace = (get: () => AppState) => {
  const state = get();
  if (!state.isAuthenticated) return;
  const workspace = toWorkspace(state);
  saveJson(getWorkspaceKey(state.currentUser.id), workspace);
  void saveRemoteWorkspace(state.currentUser.id, workspace);
};

export const useStore = create<AppState>((set, get) => ({
  currentUser: CURRENT_USER,
  allUsers: MOCK_USERS,
  teams: MOCK_TEAMS,
  allTeams: MOCK_TEAMS,
  joinRequests: [],
  tasks: MOCK_TASKS,
  reminders: MOCK_REMINDERS,
  messages: MOCK_MESSAGES,
  documents: MOCK_DOCUMENTS,
  submissionLinks: MOCK_SUBMISSION_LINKS,
  isAuthenticated: false,
  isAuthLoading: false,
  isBootstrapped: false,
  authError: null,

  initializeApp: async () => {
    set({ isAuthLoading: true, authError: null });

    let user: User | null = null;

    if (isSupabaseConfigured && supabase) {
      const { data } = await supabase.auth.getSession();
      const sessionUser = data.session?.user;
      if (sessionUser?.email) {
        const metaName = (sessionUser.user_metadata?.name as string | undefined) || sessionUser.email.split('@')[0];
        const avatar = metaName.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
        user = {
          id: sessionUser.id,
          name: metaName,
          email: sessionUser.email,
          avatar,
        };
      }
    }

    if (!user) {
      const activeUserId = localStorage.getItem(LOCAL_ACTIVE_USER_KEY);
      if (activeUserId) {
        const users = loadJson<LocalAuthUser[]>(LOCAL_AUTH_USERS_KEY, []);
        const localUser = users.find((u) => u.id === activeUserId);
        if (localUser) {
          user = {
            id: localUser.id,
            name: localUser.name,
            email: localUser.email,
            avatar: localUser.avatar,
          };
        }
      }
    }

    if (!user) {
      set({ isAuthenticated: false, isAuthLoading: false, isBootstrapped: true });
      return;
    }

    const localWorkspace = loadLocalWorkspace(user);
    const remoteWorkspace = await loadRemoteWorkspace(user.id);
    const finalWorkspace = remoteWorkspace || localWorkspace;
    await upsertRemoteProfile(user);
    const [remoteProfiles, remoteMembershipTeams, remoteJoinRequests, initialRemoteMessages] = await Promise.all([
      loadRemoteProfiles(),
      loadRemoteTeamsForUser(user.id),
      loadRemoteJoinRequestsForLeader(user.id),
      loadRemoteMessages(finalWorkspace.teams.map((team) => team.id)),
    ]);
    const mergedTeams = mergeTeams(finalWorkspace.teams, remoteMembershipTeams);
    const allTeams = mergeTeams(finalWorkspace.allTeams?.length ? finalWorkspace.allTeams : finalWorkspace.teams, mergedTeams);
    const remoteMessages = await loadRemoteMessages(mergedTeams.map((team) => team.id));
    const mergedMessages = [...finalWorkspace.messages];
    [...initialRemoteMessages, ...remoteMessages].forEach((incoming) => {
      if (!mergedMessages.some((msg) => msg.id === incoming.id)) {
        mergedMessages.push(incoming);
      }
    });

    set({
      currentUser: user,
      isAuthenticated: true,
      isAuthLoading: false,
      isBootstrapped: true,
      ...finalWorkspace,
      teams: mergedTeams,
      allTeams,
      joinRequests: remoteJoinRequests.length > 0 ? remoteJoinRequests : (finalWorkspace.joinRequests || []),
      allUsers: remoteProfiles && remoteProfiles.length > 0
        ? [user, ...remoteProfiles.filter((profile) => profile.id !== user.id)]
        : finalWorkspace.allUsers,
      messages: mergedMessages,
    });

    get().initLiveChat();
  },

  initLiveChat: () => {
    if (typeof window === 'undefined') return;

    if (!browserChannel) {
      browserChannel = new BroadcastChannel('micah-live-chat');
    }

    if (!browserChannelBound) {
      browserChannel.onmessage = (event: MessageEvent<ChatMessage>) => {
        const incoming = event.data;
        if (!incoming?.id) return;
        set((state) => {
          if (state.messages.some((m) => m.id === incoming.id)) return state;
          return { messages: [...state.messages, incoming] };
        });
        persistWorkspace(get);
      };
      browserChannelBound = true;
    }

    if (isSupabaseConfigured && supabase && !supabaseBroadcastChannel) {
      supabaseBroadcastChannel = supabase
        .channel('micah-live-chat')
        .on('broadcast', { event: 'new-message' }, ({ payload }) => {
          const incoming = payload as ChatMessage;
          if (!incoming?.id) return;
          set((state) => {
            if (state.messages.some((m) => m.id === incoming.id)) return state;
            return { messages: [...state.messages, incoming] };
          });
          persistWorkspace(get);
        })
        .subscribe();
    }

    if (isSupabaseConfigured && supabase && !supabaseDbChannel) {
      supabaseDbChannel = supabase
        .channel('micah-db-live-chat')
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'micah_messages' },
          (payload) => {
            const row = payload.new as {
              id?: string;
              team_id?: string;
              sender_id?: string;
              sender_name?: string;
              content?: string;
              timestamp?: string;
              is_task_assignment?: boolean;
              task_id?: string | null;
            };
            if (!row.id || !row.team_id || !row.sender_id || !row.sender_name || !row.content || !row.timestamp) return;
            const incoming: ChatMessage = {
              id: row.id,
              teamId: row.team_id,
              senderId: row.sender_id,
              senderName: row.sender_name,
              content: row.content,
              timestamp: row.timestamp,
              isTaskAssignment: Boolean(row.is_task_assignment),
              taskId: row.task_id ?? undefined,
            };

            set((state) => {
              if (state.messages.some((m) => m.id === incoming.id)) return state;
              return { messages: [...state.messages, incoming] };
            });
            persistWorkspace(get);
          }
        )
        .subscribe();
    }

    startFakeChatLoop(set, get);
  },

  login: async (email: string, password: string) => {
    set({ isAuthLoading: true, authError: null });

    try {
      if (isSupabaseConfigured && supabase) {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw new Error(error.message);
        if (!data.user?.email) throw new Error('Invalid login response from server.');

        const name = (data.user.user_metadata?.name as string | undefined) || data.user.email.split('@')[0];
        const avatar = name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
        const user: User = { id: data.user.id, name, email: data.user.email, avatar };

        const localWorkspace = loadLocalWorkspace(user);
        const remoteWorkspace = await loadRemoteWorkspace(user.id);
        const finalWorkspace = remoteWorkspace || localWorkspace;
        await upsertRemoteProfile(user);
        const [remoteProfiles, remoteMembershipTeams, remoteJoinRequests, initialRemoteMessages] = await Promise.all([
          loadRemoteProfiles(),
          loadRemoteTeamsForUser(user.id),
          loadRemoteJoinRequestsForLeader(user.id),
          loadRemoteMessages(finalWorkspace.teams.map((team) => team.id)),
        ]);
        const mergedTeams = mergeTeams(finalWorkspace.teams, remoteMembershipTeams);
        const allTeams = mergeTeams(finalWorkspace.allTeams?.length ? finalWorkspace.allTeams : finalWorkspace.teams, mergedTeams);
        const remoteMessages = await loadRemoteMessages(mergedTeams.map((team) => team.id));
        const mergedMessages = [...finalWorkspace.messages];
        [...initialRemoteMessages, ...remoteMessages].forEach((incoming) => {
          if (!mergedMessages.some((msg) => msg.id === incoming.id)) {
            mergedMessages.push(incoming);
          }
        });

        localStorage.setItem(LOCAL_ACTIVE_USER_KEY, user.id);
        set({
          currentUser: user,
          isAuthenticated: true,
          isAuthLoading: false,
          authError: null,
          ...finalWorkspace,
          teams: mergedTeams,
          allTeams,
          joinRequests: remoteJoinRequests.length > 0 ? remoteJoinRequests : (finalWorkspace.joinRequests || []),
          allUsers: remoteProfiles && remoteProfiles.length > 0
            ? [user, ...remoteProfiles.filter((profile) => profile.id !== user.id)]
            : finalWorkspace.allUsers,
          messages: mergedMessages,
        });
        get().initLiveChat();
        return;
      }

      const users = loadJson<LocalAuthUser[]>(LOCAL_AUTH_USERS_KEY, []);
      const localUser = users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
      if (!localUser) {
        throw new Error('Invalid email or password.');
      }

      const user: User = {
        id: localUser.id,
        name: localUser.name,
        email: localUser.email,
        avatar: localUser.avatar,
      };

      localStorage.setItem(LOCAL_ACTIVE_USER_KEY, user.id);
      const workspace = loadLocalWorkspace(user);
      set({ currentUser: user, isAuthenticated: true, isAuthLoading: false, authError: null, ...workspace });
      get().initLiveChat();
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to login.';
      set({ isAuthLoading: false, authError: message, isAuthenticated: false });
      throw error;
    }
  },

  register: async (name: string, email: string, password: string) => {
    set({ isAuthLoading: true, authError: null });
    const avatar = name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

    try {
      if (isSupabaseConfigured && supabase) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { name, avatar },
          },
        });
        if (error) throw new Error(error.message);

        const user: User = {
          id: data.user?.id || `user-${Date.now()}`,
          name,
          email,
          avatar,
        };

        localStorage.setItem(LOCAL_ACTIVE_USER_KEY, user.id);
        const workspace = getInitialWorkspace(user);
        saveJson(getWorkspaceKey(user.id), workspace);
        void saveRemoteWorkspace(user.id, workspace);

        await upsertRemoteProfile(user);
        const remoteProfiles = await loadRemoteProfiles();

        set({
          currentUser: user,
          isAuthenticated: true,
          isAuthLoading: false,
          authError: null,
          ...workspace,
          allUsers: remoteProfiles && remoteProfiles.length > 0
            ? [user, ...remoteProfiles.filter((profile) => profile.id !== user.id)]
            : workspace.allUsers,
        });
        get().initLiveChat();
        return;
      }

      const users = loadJson<LocalAuthUser[]>(LOCAL_AUTH_USERS_KEY, []);
      const alreadyExists = users.some((u) => u.email.toLowerCase() === email.toLowerCase());
      if (alreadyExists) {
        throw new Error('An account with this email already exists.');
      }

      const user: LocalAuthUser = {
        id: `user-${Date.now()}`,
        name,
        email,
        avatar,
        password,
      };

      saveJson(LOCAL_AUTH_USERS_KEY, [...users, user]);
      localStorage.setItem(LOCAL_ACTIVE_USER_KEY, user.id);

      const workspace = getInitialWorkspace(user);
      saveJson(getWorkspaceKey(user.id), workspace);

      set({
        currentUser: { id: user.id, name: user.name, email: user.email, avatar: user.avatar },
        isAuthenticated: true,
        isAuthLoading: false,
        authError: null,
        ...workspace,
      });
      get().initLiveChat();
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to register.';
      set({ isAuthLoading: false, authError: message, isAuthenticated: false });
      throw error;
    }
  },

  logout: async () => {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    }

    localStorage.removeItem(LOCAL_ACTIVE_USER_KEY);

    if (supabaseBroadcastChannel && supabase) {
      void supabase.removeChannel(supabaseBroadcastChannel);
      supabaseBroadcastChannel = null;
    }

    if (supabaseDbChannel && supabase) {
      void supabase.removeChannel(supabaseDbChannel);
      supabaseDbChannel = null;
    }

    if (typeof window !== 'undefined' && fakeChatIntervalId) {
      window.clearInterval(fakeChatIntervalId);
      fakeChatIntervalId = null;
      fakeChatIntervalOwnerId = null;
    }

    if (typeof window !== 'undefined' && fakeTaskResponseTimers.size > 0) {
      fakeTaskResponseTimers.forEach((timerId) => window.clearTimeout(timerId));
      fakeTaskResponseTimers.clear();
    }

    set({
      currentUser: CURRENT_USER,
      allUsers: MOCK_USERS,
      teams: MOCK_TEAMS,
      allTeams: MOCK_TEAMS,
      joinRequests: [],
      tasks: MOCK_TASKS,
      reminders: MOCK_REMINDERS,
      messages: MOCK_MESSAGES,
      documents: MOCK_DOCUMENTS,
      submissionLinks: MOCK_SUBMISSION_LINKS,
      isAuthenticated: false,
      authError: null,
    });
  },

  createTeam: (name: string, description: string, memberIds?: string[]) => {
    const { currentUser, teams, allTeams } = get();
    const members = [currentUser.id, ...(memberIds || []).filter((id) => id !== currentUser.id)];
    const newTeam: Team = {
      id: `team-${Date.now()}`,
      name,
      description,
      createdBy: currentUser.id,
      leaderId: currentUser.id,
      members,
      color: ['#3B82F6', '#F97316', '#6366F1', '#10B981', '#EC4899'][Math.floor(Math.random() * 5)],
    };
    set({ teams: [...teams, newTeam], allTeams: mergeTeams(allTeams, [newTeam]) });
    void createRemoteTeam(newTeam);
    persistWorkspace(get);
  },

  addMembersToTeam: (teamId: string, memberIds: string[]) => {
    if (memberIds.length === 0) return;

    const { currentUser, teams } = get();
    const team = teams.find((t) => t.id === teamId);
    if (!team) return;

    const canManageMembers = team.leaderId === currentUser.id || team.createdBy === currentUser.id;
    if (!canManageMembers) return;

    set((state) => ({
      teams: state.teams.map((existingTeam) => {
        if (existingTeam.id !== teamId) return existingTeam;
        const mergedMembers = Array.from(new Set([...existingTeam.members, ...memberIds]));
        return { ...existingTeam, members: mergedMembers };
      }),
      allTeams: state.allTeams.map((existingTeam) => {
        if (existingTeam.id !== teamId) return existingTeam;
        const mergedMembers = Array.from(new Set([...existingTeam.members, ...memberIds]));
        return { ...existingTeam, members: mergedMembers };
      }),
    }));

    void addRemoteTeamMembers(teamId, memberIds);
    persistWorkspace(get);
  },

  searchTeams: async (query: string) => {
    const trimmed = query.trim().toLowerCase();
    const { allTeams, currentUser } = get();
    const localMatches = trimmed
      ? allTeams.filter(
          (team) =>
            team.name.toLowerCase().includes(trimmed) ||
            team.description.toLowerCase().includes(trimmed)
        )
      : allTeams;

    const remoteMatches = await searchRemoteTeams(query);
    const mergedRemote = mergeTeams(allTeams, remoteMatches);

    if (remoteMatches.length > 0) {
      set((state) => {
        const nextAllTeams = mergeTeams(state.allTeams, remoteMatches);
        const remoteJoinedByUser = remoteMatches.filter((team) => team.members.includes(currentUser.id));
        return {
          allTeams: nextAllTeams,
          teams: mergeTeams(state.teams, remoteJoinedByUser),
        };
      });
      persistWorkspace(get);
    }

    const resultMap = new Map<string, Team>();
    mergeTeams(localMatches, mergedRemote).forEach((team) => resultMap.set(team.id, team));
    return Array.from(resultMap.values());
  },

  requestJoinTeam: async (teamId: string) => {
    const { currentUser, allTeams, joinRequests } = get();
    const targetTeam = allTeams.find((team) => team.id === teamId);
    if (!targetTeam) {
      return { ok: false, message: 'Team not found.' };
    }
    if (targetTeam.members.includes(currentUser.id)) {
      return { ok: false, message: 'You are already a member of this team.' };
    }

    const existingPending = joinRequests.some(
      (request) => request.teamId === teamId && request.requesterId === currentUser.id && request.status === 'pending'
    );
    if (existingPending) {
      return { ok: false, message: 'You already have a pending request for this team.' };
    }

    const request: JoinRequest = {
      id: `join-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      teamId,
      requesterId: currentUser.id,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    set((state) => ({ joinRequests: [request, ...state.joinRequests] }));
    void createRemoteJoinRequest(request);
    persistWorkspace(get);
    return { ok: true, message: `Join request sent to ${targetTeam.name}.` };
  },

  reviewJoinRequest: async (requestId: string, decision: 'accepted' | 'rejected') => {
    const { currentUser, joinRequests, allTeams } = get();
    const request = joinRequests.find((entry) => entry.id === requestId);
    if (!request || request.status !== 'pending') return;

    const team = allTeams.find((entry) => entry.id === request.teamId);
    if (!team) return;
    const canReview = team.leaderId === currentUser.id || team.createdBy === currentUser.id;
    if (!canReview) return;

    const reviewedAt = new Date().toISOString();

    set((state) => {
      const nextJoinRequests = state.joinRequests.map((entry) =>
        entry.id === requestId
          ? { ...entry, status: decision, reviewedAt, reviewedBy: currentUser.id }
          : entry
      );

      if (decision !== 'accepted') {
        return { joinRequests: nextJoinRequests };
      }

      const addMember = (entry: Team) => {
        if (entry.id !== request.teamId) return entry;
        return { ...entry, members: Array.from(new Set([...entry.members, request.requesterId])) };
      };

      return {
        joinRequests: nextJoinRequests,
        teams: state.teams.map(addMember),
        allTeams: state.allTeams.map(addMember),
      };
    });

    if (decision === 'accepted') {
      await addRemoteTeamMembers(request.teamId, [request.requesterId]);
    }
    await updateRemoteJoinRequest(requestId, { status: decision, reviewedBy: currentUser.id, reviewedAt });
    persistWorkspace(get);
  },

  deleteTeam: (teamId: string) => {
    set((state) => ({
      teams: state.teams.filter((t) => t.id !== teamId),
      allTeams: state.allTeams.filter((t) => t.id !== teamId),
      joinRequests: state.joinRequests.filter((request) => request.teamId !== teamId),
    }));
    persistWorkspace(get);
  },

  leaveTeam: (teamId: string) => {
    const { currentUser } = get();
    set((state) => ({
      teams: state.teams.map((t) =>
        t.id === teamId ? { ...t, members: t.members.filter((m) => m !== currentUser.id) } : t
      ),
      allTeams: state.allTeams.map((t) =>
        t.id === teamId ? { ...t, members: t.members.filter((m) => m !== currentUser.id) } : t
      ),
    }));
    persistWorkspace(get);
  },

  findUsers: async (query: string) => {
    const trimmed = query.trim().toLowerCase();
    const { allUsers } = get();

    const localMatches = trimmed
      ? allUsers.filter(
          (u) =>
            u.name.toLowerCase().includes(trimmed) ||
            u.email.toLowerCase().includes(trimmed)
        )
      : allUsers;

    const remoteMatches = await searchRemoteProfiles(query);

    const merged = new Map<string, User>();
    // In cloud mode, prioritize real account discovery from Supabase profiles.
    if (!isSupabaseConfigured) {
      localMatches.forEach((user) => merged.set(user.id, user));
    }
    remoteMatches.forEach((user) => merged.set(user.id, user));

    if (isSupabaseConfigured && trimmed) {
      localMatches.forEach((user) => merged.set(user.id, user));
    }

    if (remoteMatches.length > 0) {
      set((state) => {
        const nextUsers = new Map(state.allUsers.map((user) => [user.id, user]));
        remoteMatches.forEach((user) => nextUsers.set(user.id, user));
        return { allUsers: Array.from(nextUsers.values()) };
      });
      persistWorkspace(get);
    }

    return Array.from(merged.values());
  },

  seedTestProfiles: () => {
    const { currentUser } = get();
    const teamId = 'team-seed-collab';
    const missingUsers = TEST_PROFILES.filter((profile) => !get().allUsers.some((user) => user.id === profile.id));

    set((state) => {
      const nextUsers = new Map(state.allUsers.map((user) => [user.id, user]));
      TEST_PROFILES.forEach((profile) => nextUsers.set(profile.id, profile));

      const existingTeam = state.teams.find((team) => team.id === teamId);
      const seededMembers = [currentUser.id, 'fake-user-101', 'fake-user-102'];
      const nextTeams = existingTeam
        ? state.teams.map((team) =>
            team.id === teamId
              ? { ...team, members: Array.from(new Set([...team.members, ...seededMembers])) }
              : team
          )
        : [
            ...state.teams,
            {
              id: teamId,
              name: 'Test Collaboration Lab',
              description: 'Sandbox team with generated test users for member-add and chat/task testing.',
              createdBy: currentUser.id,
              leaderId: currentUser.id,
              members: seededMembers,
              color: '#3B82F6',
            },
          ];

      const nextMessages = [...state.messages];
      const scriptedMessages: ChatMessage[] = [
        {
          id: 'seed-msg-1',
          teamId,
          senderId: 'fake-user-101',
          senderName: 'Nina Brooks',
          content: 'Hey all, I joined this test workspace so you can validate adding members and team chat behavior.',
          timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
        },
        {
          id: 'seed-msg-2',
          teamId,
          senderId: 'fake-user-102',
          senderName: 'Owen Clarke',
          content: 'Assigning a sample task now so workflow testing is easier.',
          timestamp: new Date(Date.now() - 1000 * 60 * 13).toISOString(),
        },
        {
          id: 'seed-msg-3',
          teamId,
          senderId: 'fake-user-102',
          senderName: 'Owen Clarke',
          content: `📋 Task assigned to @${currentUser.name}: "Draft test acceptance notes" — Deadline: ${new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString().slice(0, 10)}. You have 3 minutes to accept.`,
          timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
          isTaskAssignment: true,
          taskId: 'seed-task-1',
        },
      ];

      scriptedMessages.forEach((message) => {
        if (!nextMessages.some((existing) => existing.id === message.id)) {
          nextMessages.push(message);
        }
      });

      const nextTasks = [...state.tasks];
      const scriptedTasks: Task[] = [
        {
          id: 'seed-task-1',
          title: 'Draft test acceptance notes',
          description: 'Write short notes confirming add-member flow and chat responsiveness.',
          teamId,
          assignedTo: currentUser.id,
          assignedBy: 'fake-user-102',
          status: 'pending-acceptance',
          deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString().slice(0, 10),
          createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
        },
        {
          id: 'seed-task-2',
          title: 'Post team standup summary',
          description: 'Send a short standup summary in the team chat.',
          teamId,
          assignedTo: 'fake-user-101',
          assignedBy: currentUser.id,
          status: 'in-progress',
          deadline: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3).toISOString().slice(0, 10),
          createdAt: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
          acceptedAt: new Date(Date.now() - 1000 * 60 * 9).toISOString(),
        },
      ];

      scriptedTasks.forEach((task) => {
        if (!nextTasks.some((existing) => existing.id === task.id)) {
          nextTasks.push(task);
        }
      });

      return {
        allUsers: Array.from(nextUsers.values()),
        teams: nextTeams,
        allTeams: mergeTeams(state.allTeams, nextTeams),
        messages: nextMessages,
        tasks: nextTasks,
      };
    });

    if (missingUsers.length > 0) {
      void Promise.all(missingUsers.map((profile) => upsertRemoteProfile(profile)));
    }

    persistWorkspace(get);
  },

  addTask: (title, description, teamId, assignedTo, deadline) => {
    const { currentUser, tasks } = get();
    const newTask: Task = {
      id: `task-${Date.now()}`,
      title,
      description,
      teamId,
      assignedTo,
      assignedBy: currentUser.id,
      status: 'pending-acceptance',
      deadline,
      createdAt: new Date().toISOString(),
    };
    set({ tasks: [...tasks, newTask] });
    persistWorkspace(get);
    return newTask;
  },

  acceptTask: (taskId: string) => {
    const task = get().tasks.find((entry) => entry.id === taskId);
    if (!task || task.status !== 'pending-acceptance') return;

    const acceptedAt = new Date().toISOString();
    set((state) => ({
      tasks: state.tasks.map((t) =>
        t.id === taskId ? { ...t, status: 'in-progress' as const, acceptedAt } : t
      ),
    }));
    persistWorkspace(get);

    const accepter = get().allUsers.find((user) => user.id === task.assignedTo) || get().currentUser;
    const acceptedNotice = buildChatMessage(
      task.teamId,
      accepter,
      `[Accepted] @${accepter.name} accepted task "${task.title}".`
    );
    publishMessage(set, get, acceptedNotice);
  },

  dropTask: (taskId: string) => {
    set((state) => ({
      tasks: state.tasks.map((t) =>
        t.id === taskId ? { ...t, status: 'dropped' as const } : t
      ),
    }));
    persistWorkspace(get);
  },

  completeTask: (taskId: string) => {
    set((state) => ({
      tasks: state.tasks.map((t) =>
        t.id === taskId ? { ...t, status: 'completed' as const } : t
      ),
    }));
    persistWorkspace(get);
  },

  addReminder: (name, taskId, taskTitle, teamId, sound, interval, alertTime) => {
    const { reminders } = get();
    const newReminder: Reminder = {
      id: `rem-${Date.now()}`,
      name,
      taskId,
      taskTitle,
      teamId,
      sound,
      interval,
      alertTime,
      enabled: true,
      nextAlert: getNextAlertIso(alertTime, interval),
    };
    set({ reminders: [...reminders, newReminder] });
    persistWorkspace(get);
  },

  deleteReminder: (reminderId: string) => {
    set((state) => ({ reminders: state.reminders.filter((r) => r.id !== reminderId) }));
    persistWorkspace(get);
  },

  toggleReminder: (reminderId: string) => {
    set((state) => ({
      reminders: state.reminders.map((r) =>
        r.id === reminderId
          ? {
              ...r,
              enabled: !r.enabled,
              nextAlert: getNextAlertIso(r.alertTime, r.interval),
            }
          : r
      ),
    }));
    persistWorkspace(get);
  },

  updateReminder: (reminderId, updates) => {
    set((state) => ({
      reminders: state.reminders.map((r) => {
        if (r.id !== reminderId) return r;
        const nextReminder = { ...r, ...updates };
        return {
          ...nextReminder,
          nextAlert: getNextAlertIso(nextReminder.alertTime, nextReminder.interval),
        };
      }),
    }));
    persistWorkspace(get);
  },

  updateReminderSound: (reminderId: string, sound: string) => {
    get().updateReminder(reminderId, { sound });
  },

  sendMessage: (teamId, content, isTaskAssignment = false, taskId) => {
    const msg = buildChatMessage(teamId, get().currentUser, content, isTaskAssignment, taskId);
    publishMessage(set, get, msg);

    if (isTaskAssignment && taskId) {
      const assignedTask = get().tasks.find((task) => task.id === taskId);
      if (assignedTask && isFakeProfile(assignedTask.assignedTo)) {
        scheduleFakeTaskResponse(set, get, assignedTask.id);
      }
    }
  },

  addDocument: (teamId, name, label, type, url) => {
    const { currentUser, documents } = get();
    const doc: Document = {
      id: `doc-${Date.now()}`,
      teamId,
      name,
      label,
      uploadedBy: currentUser.id,
      uploadedAt: new Date().toISOString(),
      url: url || '#',
      type,
    };
    set({ documents: [...documents, doc] });
    persistWorkspace(get);
  },

  addSubmissionLink: (teamId, title, url, expiresAt) => {
    const { submissionLinks } = get();
    const link: SubmissionLink = {
      id: `sub-${Date.now()}`,
      teamId,
      title,
      url,
      expiresAt,
    };
    set({ submissionLinks: [...submissionLinks, link] });
    persistWorkspace(get);
  },

  getUserById: (id: string) => get().allUsers.find((u) => u.id === id),
  getTeamById: (id: string) => get().teams.find((t) => t.id === id),
  getTasksForUser: () => get().tasks.filter((t) => t.assignedTo === get().currentUser.id),
  getTasksForTeam: (teamId: string) => get().tasks.filter((t) => t.teamId === teamId),
  getMessagesForTeam: (teamId: string) => get().messages.filter((m) => m.teamId === teamId),
  getDocumentsForTeam: (teamId: string) => get().documents.filter((d) => d.teamId === teamId),
  getSubmissionLinksForTeam: (teamId: string) => get().submissionLinks.filter((s) => s.teamId === teamId),
}));
