// Web Audio API sound generator for reminder alerts
let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  }
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
  return audioContext;
}

function playTone(frequency: number, duration: number, type: OscillatorType = 'sine', volume = 0.3) {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(frequency, ctx.currentTime);
  gain.gain.setValueAtTime(volume, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + duration);
}

function playSequence(notes: { freq: number; start: number; dur: number; type?: OscillatorType; vol?: number }[]) {
  notes.forEach(n => {
    setTimeout(() => {
      playTone(n.freq, n.dur, n.type || 'sine', n.vol || 0.3);
    }, n.start * 1000);
  });
}

export function playSound(soundName: string) {
  try {
    switch (soundName) {
      case 'chime':
        playSequence([
          { freq: 523, start: 0, dur: 0.3 },
          { freq: 659, start: 0.15, dur: 0.3 },
          { freq: 784, start: 0.3, dur: 0.5 },
        ]);
        break;

      case 'bell':
        playSequence([
          { freq: 830, start: 0, dur: 1.0, type: 'sine', vol: 0.4 },
          { freq: 1245, start: 0, dur: 0.6, type: 'sine', vol: 0.15 },
          { freq: 830, start: 0.8, dur: 0.8, type: 'sine', vol: 0.25 },
        ]);
        break;

      case 'ping':
        playSequence([
          { freq: 1200, start: 0, dur: 0.15, type: 'sine', vol: 0.35 },
          { freq: 1600, start: 0.1, dur: 0.12, type: 'sine', vol: 0.25 },
        ]);
        break;

      case 'alert':
        playSequence([
          { freq: 880, start: 0, dur: 0.2, type: 'square', vol: 0.2 },
          { freq: 880, start: 0.3, dur: 0.2, type: 'square', vol: 0.2 },
          { freq: 1100, start: 0.6, dur: 0.2, type: 'square', vol: 0.2 },
          { freq: 1100, start: 0.9, dur: 0.2, type: 'square', vol: 0.2 },
        ]);
        break;

      case 'melody':
        playSequence([
          { freq: 523, start: 0, dur: 0.25 },
          { freq: 587, start: 0.2, dur: 0.25 },
          { freq: 659, start: 0.4, dur: 0.25 },
          { freq: 784, start: 0.6, dur: 0.4 },
          { freq: 659, start: 1.0, dur: 0.25 },
          { freq: 784, start: 1.2, dur: 0.5 },
        ]);
        break;

      case 'whistle':
        playSequence([
          { freq: 1000, start: 0, dur: 0.4, type: 'sine', vol: 0.3 },
          { freq: 1400, start: 0.2, dur: 0.3, type: 'sine', vol: 0.25 },
          { freq: 1800, start: 0.4, dur: 0.5, type: 'sine', vol: 0.2 },
        ]);
        break;

      case 'pop': {
        const ctx = getAudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.4, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.2);

        setTimeout(() => {
          const osc2 = ctx.createOscillator();
          const gain2 = ctx.createGain();
          osc2.type = 'sine';
          osc2.frequency.setValueAtTime(800, ctx.currentTime);
          osc2.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.12);
          gain2.gain.setValueAtTime(0.35, ctx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
          osc2.connect(gain2);
          gain2.connect(ctx.destination);
          osc2.start(ctx.currentTime);
          osc2.stop(ctx.currentTime + 0.2);
        }, 200);
        break;
      }

      case 'gentle':
        playSequence([
          { freq: 392, start: 0, dur: 0.6, type: 'sine', vol: 0.15 },
          { freq: 440, start: 0.4, dur: 0.6, type: 'sine', vol: 0.12 },
          { freq: 494, start: 0.8, dur: 0.8, type: 'sine', vol: 0.1 },
        ]);
        break;

      default:
        playTone(800, 0.3);
    }
  } catch (e) {
    console.warn('Audio playback failed:', e);
  }
}

export const SOUND_OPTIONS = [
  { value: 'chime', label: '🔔 Chime' },
  { value: 'bell', label: '🛎️ Bell' },
  { value: 'ping', label: '📳 Ping' },
  { value: 'alert', label: '🚨 Alert' },
  { value: 'melody', label: '🎵 Melody' },
  { value: 'whistle', label: '📯 Whistle' },
  { value: 'pop', label: '💥 Pop' },
  { value: 'gentle', label: '🌊 Gentle Wave' },
];
