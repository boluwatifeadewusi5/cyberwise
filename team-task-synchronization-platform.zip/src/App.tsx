import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store';
import Navbar from './components/Navbar';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import TeamsPage from './pages/TeamsPage';
import TasksPage from './pages/TasksPage';
import RemindersPage from './pages/RemindersPage';
import TeamChat from './pages/TeamChat';
import CommandCenter from './pages/CommandCenter';

function AuthenticatedLayout() {
  return (
    <div className="min-h-screen bg-gray-50/50">
      <Navbar />
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/teams" element={<TeamsPage />} />
        <Route path="/teams/:teamId/chat" element={<TeamChat />} />
        <Route path="/tasks" element={<TasksPage />} />
        <Route path="/reminders" element={<RemindersPage />} />
        <Route path="/command-center" element={<CommandCenter />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </div>
  );
}

export default function App() {
  const { isAuthenticated, isAuthLoading, isBootstrapped, initializeApp } = useStore();

  useEffect(() => {
    void initializeApp();
  }, [initializeApp]);

  if (!isBootstrapped || isAuthLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="mx-auto mb-3 h-10 w-10 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center">M</div>
          <p className="text-sm font-semibold text-gray-600">Loading Micah...</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {!isAuthenticated ? (
          <>
            <Route path="/" element={<RegisterPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </>
        ) : (
          <Route path="/*" element={<AuthenticatedLayout />} />
        )}
      </Routes>
    </BrowserRouter>
  );
}
