import { useState, useMemo } from 'react';
import { Plus, CheckCircle2, Clock, AlertCircle, X, ChevronDown, XCircle } from 'lucide-react';
import { useStore } from '../store';

const STATUS_CONFIG = {
  'pending-acceptance': { label: 'Pending', color: 'bg-orange-50 text-orange-700 border-orange-200', icon: Clock, dot: 'bg-orange-400' },
  'in-progress': { label: 'In Progress', color: 'bg-blue-50 text-blue-700 border-blue-200', icon: AlertCircle, dot: 'bg-blue-400' },
  'completed': { label: 'Completed', color: 'bg-green-50 text-green-700 border-green-200', icon: CheckCircle2, dot: 'bg-green-400' },
  'dropped': { label: 'Dropped', color: 'bg-gray-50 text-gray-500 border-gray-200', icon: XCircle, dot: 'bg-gray-400' },
};

export default function TasksPage() {
  const { currentUser, teams, tasks, allUsers, addTask, acceptTask, dropTask, completeTask } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [visibleCount, setVisibleCount] = useState(6);
  const [newTask, setNewTask] = useState({ title: '', description: '', teamId: '', assignedTo: '', deadline: '' });

  const myTasks = useMemo(() => {
    let filtered = tasks.filter(t => t.assignedTo === currentUser.id);
    if (filter !== 'all') filtered = filtered.filter(t => t.status === filter);
    return filtered;
  }, [tasks, currentUser.id, filter]);

  const completionStats = useMemo(() => {
    const total = tasks.filter(t => t.assignedTo === currentUser.id).length;
    const completed = tasks.filter(t => t.assignedTo === currentUser.id && t.status === 'completed').length;
    const percentage = total === 0 ? 0 : Math.round((completed / total) * 100);
    return { total, completed, percentage };
  }, [tasks, currentUser.id]);

  const visibleTasks = myTasks.slice(0, visibleCount);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTask.title.trim() && newTask.teamId) {
      addTask(newTask.title, newTask.description, newTask.teamId, newTask.assignedTo || currentUser.id, newTask.deadline);
      setNewTask({ title: '', description: '', teamId: '', assignedTo: '', deadline: '' });
      setShowAdd(false);
    }
  };

  const myTeams = teams.filter(t => t.members.includes(currentUser.id));

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">My Tasks</h1>
          <p className="text-gray-500 text-sm mt-1">{myTasks.length} task{myTasks.length !== 1 ? 's' : ''} across all teams</p>
          <div className="mt-3 max-w-sm">
            <div className="flex items-center justify-between text-xs font-semibold text-gray-600 mb-1.5">
              <span>Completed Progress</span>
              <span>{completionStats.completed}/{completionStats.total} ({completionStats.percentage}%)</span>
            </div>
            <div className="h-2 w-full rounded-full bg-gray-100 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-300"
                style={{ width: `${completionStats.percentage}%` }}
              />
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-orange-400 to-orange-500 text-white font-semibold text-sm rounded-xl shadow-lg shadow-orange-200 hover:shadow-xl transition-all"
        >
          <Plus size={16} /> Add New Task
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
        {[
          { key: 'all', label: 'All Tasks' },
          { key: 'pending-acceptance', label: 'Pending' },
          { key: 'in-progress', label: 'In Progress' },
          { key: 'completed', label: 'Completed' },
          { key: 'dropped', label: 'Dropped' },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => { setFilter(f.key); setVisibleCount(6); }}
            className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
              filter === f.key
                ? 'bg-blue-600 text-white shadow-md shadow-blue-200'
                : 'bg-white text-gray-600 border border-gray-200 hover:border-blue-200 hover:text-blue-600'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Tasks List — progressive loading */}
      {visibleTasks.length === 0 ? (
        <div className="text-center py-20">
          <CheckCircle2 size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-bold text-gray-400">No tasks found</h3>
          <p className="text-sm text-gray-400 mt-1">Tasks assigned to you will appear here</p>
        </div>
      ) : (
        <div className="space-y-3">
          {visibleTasks.map(task => {
            const team = teams.find(t => t.id === task.teamId);
            const assignedBy = allUsers.find(u => u.id === task.assignedBy);
            const config = STATUS_CONFIG[task.status];
            const StatusIcon = config.icon;
            const daysLeft = Math.ceil((new Date(task.deadline).getTime() - Date.now()) / 86400000);

            return (
              <div
                key={task.id}
                className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all duration-200 group"
              >
                <div className="flex items-start gap-4">
                  {/* Status Dot */}
                  <div className={`w-3 h-3 rounded-full ${config.dot} mt-1.5 flex-shrink-0`} />

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <h3 className="font-bold text-gray-900">{task.title}</h3>
                        <p className="text-sm text-gray-500 mt-0.5 line-clamp-2">{task.description}</p>
                      </div>
                      <span className={`flex-shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${config.color}`}>
                        <StatusIcon size={12} /> {config.label}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
                      <span className="font-semibold text-gray-600">{team?.name}</span>
                      <span>•</span>
                      <span>Assigned by {assignedBy?.name}</span>
                      <span>•</span>
                      <span className={daysLeft <= 3 && task.status !== 'completed' ? 'text-red-500 font-bold' : ''}>
                        Due {new Date(task.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        {task.status !== 'completed' && task.status !== 'dropped' && (
                          <> ({daysLeft <= 0 ? 'Overdue!' : `${daysLeft}d left`})</>
                        )}
                      </span>
                    </div>

                    {/* Actions */}
                    {task.status === 'pending-acceptance' && (
                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() => acceptTask(task.id)}
                          className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors"
                        >
                          Accept Task
                        </button>
                        <button
                          onClick={() => dropTask(task.id)}
                          className="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-600 text-xs font-semibold rounded-lg transition-colors"
                        >
                          Decline
                        </button>
                        <span className="text-xs text-orange-500 font-semibold self-center ml-2">⏱ 3 min to respond</span>
                      </div>
                    )}
                    {task.status === 'in-progress' && (
                      <div className="mt-3">
                        <button
                          onClick={() => completeTask(task.id)}
                          className="px-4 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold rounded-lg transition-colors"
                        >
                          Mark as Complete ✓
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Load More */}
      {visibleCount < myTasks.length && (
        <div className="text-center mt-6">
          <button
            onClick={() => setVisibleCount(prev => prev + 6)}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-white border border-gray-200 hover:border-blue-300 text-gray-700 font-semibold text-sm rounded-xl transition-colors"
          >
            <ChevronDown size={16} /> Load More Tasks
          </button>
        </div>
      )}

      {/* Add Task Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowAdd(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Add New Task</h3>
              <button onClick={() => setShowAdd(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <X size={18} className="text-gray-400" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Task Title</label>
                <input
                  type="text"
                  value={newTask.title}
                  onChange={e => setNewTask({ ...newTask, title: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  placeholder="e.g. Write project proposal"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                <textarea
                  value={newTask.description}
                  onChange={e => setNewTask({ ...newTask, description: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm resize-none"
                  rows={2}
                  placeholder="Describe the task..."
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Team</label>
                <select
                  value={newTask.teamId}
                  onChange={e => setNewTask({ ...newTask, teamId: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  required
                >
                  <option value="">Select team...</option>
                  {myTeams.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Deadline</label>
                <input
                  type="date"
                  value={newTask.deadline}
                  onChange={e => setNewTask({ ...newTask, deadline: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-orange-400 to-orange-500 text-white font-semibold rounded-xl shadow-lg shadow-orange-200 text-sm"
              >
                Add Task
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
