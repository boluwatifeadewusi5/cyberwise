import { useState, useRef, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Send, ArrowLeft, CheckSquare, FileText, Link2, Upload, X, Plus, Clock, CheckCircle2, AlertCircle, XCircle, Users, Check, Download } from 'lucide-react';
import { useStore } from '../store';

const STATUS_CONFIG = {
  'pending-acceptance': { label: 'Pending', color: 'bg-orange-50 text-orange-700', icon: Clock },
  'in-progress': { label: 'In Progress', color: 'bg-blue-50 text-blue-700', icon: AlertCircle },
  'completed': { label: 'Completed', color: 'bg-green-50 text-green-700', icon: CheckCircle2 },
  'dropped': { label: 'Dropped', color: 'bg-gray-50 text-gray-500', icon: XCircle },
};

export default function TeamChat() {
  const { teamId } = useParams<{ teamId: string }>();
  const {
    currentUser, allUsers, teams, tasks, messages, documents, submissionLinks,
    sendMessage, addTask, acceptTask, dropTask, completeTask, addDocument, addSubmissionLink,
    getMessagesForTeam, getTasksForTeam, getDocumentsForTeam, getSubmissionLinksForTeam,
  } = useStore();

  const team = teams.find(t => t.id === teamId);
  const [msgInput, setMsgInput] = useState('');
  const [showTaskPanel, setShowTaskPanel] = useState(false);
  const [activeTab, setActiveTab] = useState<'tasks' | 'docs' | 'links' | 'members'>('tasks');
  const [showTaskCreate, setShowTaskCreate] = useState(false);
  const [showDocUpload, setShowDocUpload] = useState(false);
  const [showLinkAdd, setShowLinkAdd] = useState(false);
  const [newTaskForm, setNewTaskForm] = useState({ title: '', description: '', assignedTo: '', deadline: '' });
  const [newDoc, setNewDoc] = useState({ name: '', label: 'User Personas', type: 'file' });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [newLink, setNewLink] = useState({ title: '', url: '', expiresAt: '' });
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const teamMessages = useMemo(() => teamId ? getMessagesForTeam(teamId) : [], [teamId, messages]);
  const teamTasks = useMemo(() => teamId ? getTasksForTeam(teamId) : [], [teamId, tasks]);
  const teamDocs = useMemo(() => teamId ? getDocumentsForTeam(teamId) : [], [teamId, documents]);
  const teamLinks = useMemo(() => teamId ? getSubmissionLinksForTeam(teamId) : [], [teamId, submissionLinks]);

  const fileToDataUrl = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
        return;
      }
      reject(new Error('Failed to read file'));
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [teamMessages.length]);

  if (!team || !teamId) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <p className="text-gray-400">Team not found</p>
      </div>
    );
  }

  if (!team.members.includes(currentUser.id)) {
    return (
      <div className="flex h-[calc(100vh-64px)] items-center justify-center px-4">
        <div className="text-center">
          <p className="text-sm font-semibold text-gray-700">You do not have access to this team yet.</p>
          <p className="mt-1 text-xs text-gray-500">Send a join request from the Teams page and wait for leader approval.</p>
          <Link to="/teams" className="mt-4 inline-flex rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700">
            Back to Teams
          </Link>
        </div>
      </div>
    );
  }

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgInput.trim()) return;

    // Check for @mention task assignment pattern
    const mentionMatch = msgInput.match(/@(\w+\s?\w*)/);
    if (mentionMatch) {
      sendMessage(teamId, msgInput, false);
    } else {
      sendMessage(teamId, msgInput);
    }
    setMsgInput('');
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskForm.title.trim() && newTaskForm.assignedTo) {
      const newTask = addTask(newTaskForm.title, newTaskForm.description, teamId, newTaskForm.assignedTo, newTaskForm.deadline);
      const assignee = allUsers.find(u => u.id === newTaskForm.assignedTo);
      sendMessage(
        teamId,
        `📋 Task assigned to @${assignee?.name}: "${newTaskForm.title}" — Deadline: ${newTaskForm.deadline}. You have 3 minutes to accept.`,
        true,
        newTask.id
      );
      setNewTaskForm({ title: '', description: '', assignedTo: '', deadline: '' });
      setShowTaskCreate(false);
    }
  };

  const handleUploadDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newDoc.name.trim() && selectedFile) {
      try {
        const fileType = selectedFile.type || selectedFile.name.split('.').pop() || 'file';
        // Store as data URL so download links remain valid across refreshes.
        const fileUrl = await fileToDataUrl(selectedFile);

        addDocument(teamId, newDoc.name, newDoc.label, fileType, fileUrl);
        sendMessage(teamId, `📄 Document uploaded: "${newDoc.name}" [${newDoc.label}]`);
        setNewDoc({ name: '', label: 'User Personas', type: 'file' });
        setSelectedFile(null);
        setIsDraggingFile(false);
        setShowDocUpload(false);
      } catch {
        // Keep failure handling minimal in UI; users can retry immediately.
      }
    }
  };

  const handleDownloadDoc = async (doc: (typeof teamDocs)[number]) => {
    if (!doc.url || doc.url === '#') return;

    const triggerDownload = (href: string) => {
      const link = document.createElement('a');
      link.href = href;
      link.download = doc.name;
      document.body.appendChild(link);
      link.click();
      link.remove();
    };

    if (doc.url.startsWith('data:') || doc.url.startsWith('blob:')) {
      triggerDownload(doc.url);
      return;
    }

    try {
      const response = await fetch(doc.url);
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      triggerDownload(objectUrl);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    } catch {
      window.open(doc.url, '_blank', 'noopener');
    }
  };

  const handleFileSelection = (file: File | null) => {
    if (!file) return;

    setSelectedFile(file);
    setNewDoc(prev => ({
      ...prev,
      name: prev.name.trim() ? prev.name : file.name,
      type: file.type || file.name.split('.').pop() || 'file',
    }));
  };

  const handleAddLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (newLink.title.trim() && newLink.url.trim()) {
      addSubmissionLink(teamId, newLink.title, newLink.url, newLink.expiresAt);
      sendMessage(teamId, `🔗 Submission link added: "${newLink.title}" — expires ${new Date(newLink.expiresAt).toLocaleDateString()}`);
      setNewLink({ title: '', url: '', expiresAt: '' });
      setShowLinkAdd(false);
    }
  };

  const memberNames = team.members.map(id => allUsers.find(u => u.id === id));
  const DOC_LABELS = ['User Personas', 'Tech Stack Description', 'Update Report', 'Research Data', 'Slides', 'Other'];

  const getPendingTaskForMessage = (taskMessageId?: string, content?: string) => {
    if (taskMessageId) {
      const linkedTask = teamTasks.find(t => t.id === taskMessageId);
      if (linkedTask && linkedTask.assignedTo === currentUser.id && linkedTask.status === 'pending-acceptance') {
        return linkedTask;
      }
    }

    // Fallback for older task messages that were sent before taskId was attached.
    const titleMatch = content?.match(/"([^"]+)"/);
    const referencedTitle = titleMatch?.[1]?.trim();
    if (!referencedTitle) return undefined;

    return teamTasks.find(
      (task) => task.title === referencedTitle && task.assignedTo === currentUser.id && task.status === 'pending-acceptance'
    );
  };

  const closeDocUploadModal = () => {
    setShowDocUpload(false);
    setIsDraggingFile(false);
    setSelectedFile(null);
    setNewDoc({ name: '', label: 'User Personas', type: 'file' });
  };

  return (
    <div className="h-[calc(100vh-64px)] flex">
      {/* Chat Panel */}
      <div className={`flex flex-col transition-all duration-300 ${showTaskPanel ? 'w-[70%]' : 'w-full'}`}>
        {/* Chat Header */}
        <div className="bg-white border-b border-gray-100 px-4 sm:px-6 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <Link to="/teams" className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 lg:hidden">
              <ArrowLeft size={18} />
            </Link>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
              {team.name.charAt(0)}
            </div>
            <div>
              <h2 className="font-bold text-gray-900 text-sm">{team.name}</h2>
              <p className="text-xs text-gray-500">{team.members.length} members</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (showTaskPanel && activeTab === 'tasks') {
                  setShowTaskPanel(false);
                } else {
                  setShowTaskPanel(true);
                  setActiveTab('tasks');
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                showTaskPanel && activeTab === 'tasks'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
              }`}
            >
              <CheckSquare size={14} /> Workflow
            </button>
            <button
              onClick={() => {
                if (showTaskPanel && activeTab === 'docs') {
                  setShowTaskPanel(false);
                } else {
                  setShowTaskPanel(true);
                  setActiveTab('docs');
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                showTaskPanel && activeTab === 'docs'
                  ? 'bg-orange-500 text-white shadow-md'
                  : 'bg-orange-50 text-orange-600 hover:bg-orange-100'
              }`}
            >
              <FileText size={14} /> Docs
            </button>
            <button
              onClick={() => {
                if (showTaskPanel && activeTab === 'members') {
                  setShowTaskPanel(false);
                } else {
                  setShowTaskPanel(true);
                  setActiveTab('members');
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                showTaskPanel && activeTab === 'members'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Users size={14} />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-gradient-to-b from-blue-50/30 to-white">
          {teamMessages.map(msg => {
            const isMe = msg.senderId === currentUser.id;
            const pendingTask = msg.isTaskAssignment ? getPendingTaskForMessage(msg.taskId, msg.content) : undefined;
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] ${isMe ? 'order-2' : 'order-1'}`}>
                  {!isMe && (
                    <p className="text-xs font-semibold text-gray-500 mb-1 ml-1">{msg.senderName}</p>
                  )}
                  <div className={`px-4 py-2.5 rounded-2xl text-sm ${
                    msg.isTaskAssignment
                      ? 'bg-orange-50 border border-orange-200 text-orange-900'
                      : isMe
                        ? 'bg-blue-600 text-white rounded-br-md'
                        : 'bg-white border border-gray-100 text-gray-800 rounded-bl-md shadow-sm'
                  }`}>
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                    {pendingTask && (
                      <div className="mt-2 flex justify-end">
                        <button
                          onClick={() => acceptTask(pendingTask.id)}
                          className="inline-flex items-center justify-center p-1 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors"
                          title="Accept task"
                          aria-label="Accept task"
                        >
                          <Check size={12} />
                        </button>
                      </div>
                    )}
                  </div>
                  <p className={`text-[10px] text-gray-400 mt-1 ${isMe ? 'text-right mr-1' : 'ml-1'}`}>
                    {new Date(msg.timestamp).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={chatEndRef} />
        </div>

        {/* Message Input */}
        <div className="bg-white border-t border-gray-100 p-4 flex-shrink-0">
          <form onSubmit={handleSend} className="flex items-center gap-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={msgInput}
                onChange={e => setMsgInput(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm pr-10"
                placeholder="Type a message... Use @name to mention members"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowTaskCreate(true)}
              className="p-2.5 rounded-xl bg-orange-50 text-orange-600 hover:bg-orange-100 transition-colors flex-shrink-0"
              title="Assign task via chat"
            >
              <Plus size={18} />
            </button>
            <button
              type="submit"
              className="p-2.5 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-md shadow-blue-200 flex-shrink-0"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      </div>

      {/* Side Panel (shrinks chat by 30%) */}
      {showTaskPanel && (
        <div className="w-[30%] border-l border-gray-100 bg-white flex flex-col overflow-hidden">
          {/* Panel Header */}
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between flex-shrink-0">
            <div className="flex gap-1">
              {(['tasks', 'docs', 'links', 'members'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
                    activeTab === tab ? 'bg-blue-600 text-white' : 'text-gray-500 hover:bg-gray-100'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
            <button onClick={() => setShowTaskPanel(false)} className="p-1 rounded-lg hover:bg-gray-100">
              <X size={16} className="text-gray-400" />
            </button>
          </div>

          {/* Panel Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {activeTab === 'tasks' && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-bold text-gray-900">Workflow Sheet</h3>
                  <button
                    onClick={() => setShowTaskCreate(true)}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700"
                  >
                    + Assign
                  </button>
                </div>
                {teamTasks.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center py-8">No tasks yet</p>
                ) : (
                  teamTasks.map(task => {
                    const config = STATUS_CONFIG[task.status];
                    const assignee = allUsers.find(u => u.id === task.assignedTo);
                    const isMyTask = task.assignedTo === currentUser.id;

                    return (
                      <div key={task.id} className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <h4 className="text-xs font-bold text-gray-900 leading-tight">{task.title}</h4>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex-shrink-0 ${config.color}`}>
                            {config.label}
                          </span>
                        </div>
                        <p className="text-[10px] text-gray-500 mb-2">
                          Assigned to <strong>{assignee?.name}</strong> • Due {new Date(task.deadline).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </p>
                        {isMyTask && task.status === 'pending-acceptance' && (
                          <div className="flex gap-1.5">
                            <button onClick={() => acceptTask(task.id)} className="px-2 py-1 bg-blue-600 text-white text-[10px] font-semibold rounded-md">Accept</button>
                            <button onClick={() => dropTask(task.id)} className="px-2 py-1 bg-gray-200 text-gray-600 text-[10px] font-semibold rounded-md">Decline</button>
                            <span className="text-[10px] text-orange-500 font-semibold self-center">⏱ 3min</span>
                          </div>
                        )}
                        {isMyTask && task.status === 'in-progress' && (
                          <button onClick={() => completeTask(task.id)} className="px-2 py-1 bg-green-600 text-white text-[10px] font-semibold rounded-md">
                            Complete ✓
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </>
            )}

            {activeTab === 'docs' && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-bold text-gray-900">Documents</h3>
                  <button
                    onClick={() => setShowDocUpload(true)}
                    className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700"
                  >
                    <Upload size={12} /> Upload
                  </button>
                </div>
                {teamDocs.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center py-8">No documents uploaded</p>
                ) : (
                  teamDocs.map(doc => {
                    const uploader = allUsers.find(u => u.id === doc.uploadedBy);
                    return (
                      <div key={doc.id} className="bg-gray-50 rounded-xl p-3 border border-gray-100 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                          <FileText size={14} className="text-blue-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="text-xs font-bold text-gray-900 truncate">{doc.name}</h4>
                          <span className="inline-block mt-0.5 px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-semibold rounded-full">
                            {doc.label}
                          </span>
                          <p className="text-[10px] text-gray-400 mt-1">
                            by {uploader?.name} • {new Date(doc.uploadedAt).toLocaleDateString()}
                          </p>
                          {doc.url !== '#' && (
                            <div className="mt-1.5 flex items-center gap-3">
                              <a
                                href={doc.url}
                                target="_blank"
                                rel="noopener"
                                className="text-[10px] font-semibold text-blue-600 hover:underline"
                              >
                                Open file
                              </a>
                              <button
                                type="button"
                                onClick={() => void handleDownloadDoc(doc)}
                                className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-600 hover:underline"
                              >
                                <Download size={10} /> Download
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </>
            )}

            {activeTab === 'links' && (
              <>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-bold text-gray-900">Submission Links</h3>
                  <button
                    onClick={() => setShowLinkAdd(true)}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700"
                  >
                    + Add Link
                  </button>
                </div>
                {teamLinks.length === 0 ? (
                  <p className="text-xs text-gray-400 text-center py-8">No submission links</p>
                ) : (
                  teamLinks.map(link => {
                    const expired = new Date(link.expiresAt).getTime() < Date.now();
                    return (
                      <div key={link.id} className={`bg-gray-50 rounded-xl p-3 border ${expired ? 'border-red-100 opacity-60' : 'border-gray-100'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <Link2 size={12} className={expired ? 'text-red-400' : 'text-blue-600'} />
                          <h4 className="text-xs font-bold text-gray-900">{link.title}</h4>
                        </div>
                        <a href={link.url} target="_blank" rel="noreferrer" className="text-[10px] text-blue-600 hover:underline truncate block">
                          {link.url}
                        </a>
                        <p className={`text-[10px] mt-1 font-semibold ${expired ? 'text-red-500' : 'text-gray-500'}`}>
                          {expired ? '⚠ Expired' : `Expires ${new Date(link.expiresAt).toLocaleDateString()}`}
                        </p>
                      </div>
                    );
                  })
                )}
              </>
            )}

            {activeTab === 'members' && (
              <>
                <h3 className="text-sm font-bold text-gray-900 mb-2">Team Members</h3>
                {memberNames.map(member => member && (
                  <div key={member.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-[10px] font-bold">
                      {member.avatar}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-900">{member.name}</p>
                      <p className="text-[10px] text-gray-500">
                        {member.id === team.leaderId ? '👑 Leader' : 'Member'}
                      </p>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {/* Task Create Modal */}
      {showTaskCreate && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowTaskCreate(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Assign Task via Chat</h3>
              <button onClick={() => setShowTaskCreate(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <X size={18} className="text-gray-400" />
              </button>
            </div>
            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Task Title</label>
                <input type="text" value={newTaskForm.title} onChange={e => setNewTaskForm({...newTaskForm, title: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" placeholder="Task title" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                <textarea value={newTaskForm.description} onChange={e => setNewTaskForm({...newTaskForm, description: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm resize-none" rows={2} />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Assign to (@member)</label>
                <select value={newTaskForm.assignedTo} onChange={e => setNewTaskForm({...newTaskForm, assignedTo: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" required>
                  <option value="">Select member...</option>
                  {team.members.filter(id => id !== currentUser.id).map(id => {
                    const u = allUsers.find(u => u.id === id);
                    return u ? <option key={u.id} value={u.id}>@{u.name}</option> : null;
                  })}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Deadline</label>
                <input type="date" value={newTaskForm.deadline} onChange={e => setNewTaskForm({...newTaskForm, deadline: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" required />
              </div>
              <button type="submit" className="w-full py-2.5 bg-gradient-to-r from-orange-400 to-orange-500 text-white font-semibold rounded-xl shadow-lg shadow-orange-200 text-sm">
                Send Task to Chat
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Doc Upload Modal */}
      {showDocUpload && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={closeDocUploadModal}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Upload Document</h3>
              <button onClick={closeDocUploadModal} className="p-1 rounded-lg hover:bg-gray-100"><X size={18} className="text-gray-400" /></button>
            </div>
            <form onSubmit={handleUploadDoc} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Select File</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={e => handleFileSelection(e.target.files?.[0] || null)}
                />
                <div
                  onDragOver={e => {
                    e.preventDefault();
                    setIsDraggingFile(true);
                  }}
                  onDragLeave={e => {
                    e.preventDefault();
                    setIsDraggingFile(false);
                  }}
                  onDrop={e => {
                    e.preventDefault();
                    setIsDraggingFile(false);
                    handleFileSelection(e.dataTransfer.files?.[0] || null);
                  }}
                  className={`border-2 border-dashed rounded-xl p-4 text-center transition-colors ${
                    isDraggingFile ? 'border-blue-400 bg-blue-50' : 'border-gray-200 bg-gray-50/70'
                  }`}
                >
                  <p className="text-xs text-gray-600">Drag and drop a document here</p>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="mt-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700"
                  >
                    Choose from computer
                  </button>
                  {selectedFile && (
                    <p className="mt-2 text-[11px] text-gray-500 truncate">
                      Selected: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
                    </p>
                  )}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Document Name</label>
                <input type="text" value={newDoc.name} onChange={e => setNewDoc({...newDoc, name: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" placeholder="e.g. User Personas v2.pdf" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Label</label>
                <select value={newDoc.label} onChange={e => setNewDoc({...newDoc, label: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm">
                  {DOC_LABELS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <button type="submit" disabled={!selectedFile} className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 disabled:from-gray-300 disabled:to-gray-300 text-white font-semibold rounded-xl shadow-lg shadow-blue-200 text-sm">
                Upload Document
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Link Modal */}
      {showLinkAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowLinkAdd(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Add Submission Link</h3>
              <button onClick={() => setShowLinkAdd(false)} className="p-1 rounded-lg hover:bg-gray-100"><X size={18} className="text-gray-400" /></button>
            </div>
            <form onSubmit={handleAddLink} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Title</label>
                <input type="text" value={newLink.title} onChange={e => setNewLink({...newLink, title: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">URL</label>
                <input type="url" value={newLink.url} onChange={e => setNewLink({...newLink, url: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Expires At</label>
                <input type="date" value={newLink.expiresAt} onChange={e => setNewLink({...newLink, expiresAt: e.target.value})} className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm" required />
              </div>
              <button type="submit" className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-xl shadow-lg shadow-blue-200 text-sm">
                Add Link
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
