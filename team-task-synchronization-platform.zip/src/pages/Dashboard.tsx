import { Link } from 'react-router-dom';
import { Users, CheckSquare, Bell, ArrowRight, Clock, TrendingUp, Zap } from 'lucide-react';
import { useStore } from '../store';

export default function Dashboard() {
  const { currentUser, teams, tasks, reminders } = useStore();

  const myTasks = tasks.filter(t => t.assignedTo === currentUser.id);
  const pendingTasks = myTasks.filter(t => t.status === 'pending-acceptance');
  const inProgressTasks = myTasks.filter(t => t.status === 'in-progress');
  const completedTasks = myTasks.filter(t => t.status === 'completed');
  const activeReminders = reminders.filter(r => r.enabled);

  const upcomingDeadlines = myTasks
    .filter(t => t.status === 'in-progress')
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 4);

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">
          Welcome back, <span className="text-blue-600">{currentUser.name.split(' ')[0]}</span>
        </h1>
        <p className="text-gray-500 mt-1 font-medium">Here's what's happening across your teams today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-2xl border border-blue-100/50 p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
              <Users size={20} className="text-blue-600" />
            </div>
            <span className="text-2xl font-extrabold text-gray-900">{teams.filter(t => t.members.includes(currentUser.id)).length}</span>
          </div>
          <p className="text-sm font-semibold text-gray-600">Active Teams</p>
        </div>

        <div className="bg-white rounded-2xl border border-orange-100/50 p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
              <Clock size={20} className="text-orange-500" />
            </div>
            <span className="text-2xl font-extrabold text-gray-900">{pendingTasks.length}</span>
          </div>
          <p className="text-sm font-semibold text-gray-600">Pending Acceptance</p>
        </div>

        <div className="bg-white rounded-2xl border border-blue-100/50 p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
              <TrendingUp size={20} className="text-blue-600" />
            </div>
            <span className="text-2xl font-extrabold text-gray-900">{inProgressTasks.length}</span>
          </div>
          <p className="text-sm font-semibold text-gray-600">In Progress</p>
        </div>

        <div className="bg-white rounded-2xl border border-green-100/50 p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
              <CheckSquare size={20} className="text-green-600" />
            </div>
            <span className="text-2xl font-extrabold text-gray-900">{completedTasks.length}</span>
          </div>
          <p className="text-sm font-semibold text-gray-600">Completed</p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Quick Navigation Cards */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-bold text-gray-900 mb-2">Quick Access</h2>

          <div className="grid sm:grid-cols-2 gap-4">
            <Link
              to="/teams"
              className="group bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-6 text-white shadow-lg shadow-blue-200 hover:shadow-xl hover:shadow-blue-300 transition-all duration-300 hover:-translate-y-0.5"
            >
              <Users size={28} className="mb-3 opacity-90" />
              <h3 className="text-lg font-bold mb-1">Teams</h3>
              <p className="text-blue-100 text-sm">Manage your teams and collaborate with members</p>
              <div className="flex items-center gap-1 mt-4 text-sm font-semibold text-blue-100 group-hover:text-white transition-colors">
                View all teams <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>

            <Link
              to="/tasks"
              className="group bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl p-6 text-white shadow-lg shadow-orange-200 hover:shadow-xl hover:shadow-orange-300 transition-all duration-300 hover:-translate-y-0.5"
            >
              <CheckSquare size={28} className="mb-3 opacity-90" />
              <h3 className="text-lg font-bold mb-1">Tasks</h3>
              <p className="text-orange-100 text-sm">Track and manage all your assigned tasks</p>
              <div className="flex items-center gap-1 mt-4 text-sm font-semibold text-orange-100 group-hover:text-white transition-colors">
                View all tasks <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>

            <Link
              to="/reminders"
              className="group bg-white rounded-2xl p-6 border border-blue-100 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-0.5"
            >
              <Bell size={28} className="mb-3 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-900 mb-1">Reminders</h3>
              <p className="text-gray-500 text-sm">Set alerts for your pending tasks</p>
              <div className="flex items-center gap-1 mt-4 text-sm font-semibold text-blue-600">
                {activeReminders.length} active <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>

            <Link
              to="/command-center"
              className="group bg-white rounded-2xl p-6 border border-orange-100 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-0.5"
            >
              <Zap size={28} className="mb-3 text-orange-500" />
              <h3 className="text-lg font-bold text-gray-900 mb-1">Command Center</h3>
              <p className="text-gray-500 text-sm">Quick access to all your tools</p>
              <div className="flex items-center gap-1 mt-4 text-sm font-semibold text-orange-500">
                Open tools <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          </div>
        </div>

        {/* Upcoming Deadlines */}
        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-4">Upcoming Deadlines</h2>
          <div className="bg-white rounded-2xl border border-blue-100/50 shadow-sm overflow-hidden">
            {upcomingDeadlines.length === 0 ? (
              <div className="p-6 text-center text-gray-400 text-sm">
                <Clock size={32} className="mx-auto mb-2 opacity-50" />
                No upcoming deadlines
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {upcomingDeadlines.map(task => {
                  const team = teams.find(t => t.id === task.teamId);
                  const daysLeft = Math.ceil((new Date(task.deadline).getTime() - Date.now()) / 86400000);
                  return (
                    <div key={task.id} className="p-4 hover:bg-blue-50/30 transition-colors">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-gray-900 truncate">{task.title}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{team?.name}</p>
                        </div>
                        <span className={`flex-shrink-0 text-xs font-bold px-2.5 py-1 rounded-full ${
                          daysLeft <= 3
                            ? 'bg-red-50 text-red-600'
                            : daysLeft <= 7
                              ? 'bg-orange-50 text-orange-600'
                              : 'bg-blue-50 text-blue-600'
                        }`}>
                          {daysLeft <= 0 ? 'Overdue' : `${daysLeft}d left`}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Pending Acceptance */}
          {pendingTasks.length > 0 && (
            <div className="mt-4">
              <h3 className="text-sm font-bold text-orange-600 mb-2 flex items-center gap-1.5">
                <Clock size={14} /> Awaiting Your Response
              </h3>
              <div className="bg-orange-50 border border-orange-100 rounded-2xl overflow-hidden">
                {pendingTasks.map(task => (
                  <div key={task.id} className="p-4 border-b border-orange-100 last:border-0">
                    <p className="text-sm font-semibold text-gray-900">{task.title}</p>
                    <p className="text-xs text-orange-600 mt-1">3 min to accept</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
