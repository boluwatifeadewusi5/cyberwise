import { useState, useEffect, useCallback, useRef } from 'react';
import { Bell, Plus, Trash2, Volume2, X, ToggleLeft, ToggleRight, Play, Clock, Pencil } from 'lucide-react';
import { useStore } from '../store';
import { playSound, SOUND_OPTIONS } from '../utils/sounds';
import type { Reminder } from '../types';

const INTERVAL_OPTIONS = [
  { value: 'hourly', label: 'Every Hour' },
  { value: 'every-2-hours', label: 'Every 2 Hours' },
  { value: 'daily', label: 'Daily' },
  { value: 'every-2-days', label: 'Every 2 Days' },
  { value: 'weekly', label: 'Weekly' },
];

function formatTime12h(time24: string): string {
  const [h, m] = time24.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 || 12;
  return `${hour12}:${m.toString().padStart(2, '0')} ${ampm}`;
}

export default function RemindersPage() {
  const { reminders, tasks, teams, currentUser, addReminder, deleteReminder, toggleReminder, updateReminder, updateReminderSound } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const [newReminder, setNewReminder] = useState({ name: '', taskId: '', sound: 'chime', interval: 'daily', alertTime: '09:00' });
  const [editingSound, setEditingSound] = useState<string | null>(null);
  const [editingReminderId, setEditingReminderId] = useState<string | null>(null);
  const [editReminderForm, setEditReminderForm] = useState({ name: '', sound: 'chime', interval: 'daily', alertTime: '09:00' });
  const [activeAlert, setActiveAlert] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const myTasks = tasks.filter(t => t.assignedTo === currentUser.id && (t.status === 'in-progress' || t.status === 'pending-acceptance'));

  // Check reminders every 30 seconds for alerts
  const checkReminders = useCallback(() => {
    const now = new Date();
    reminders.forEach(reminder => {
      if (!reminder.enabled) return;
      const alertDate = new Date(reminder.nextAlert);
      const diff = Math.abs(now.getTime() - alertDate.getTime());
      // If within 30 seconds of the alert time, fire it
      if (diff < 30000) {
        playSound(reminder.sound);
        setActiveAlert(reminder.id);
        setTimeout(() => setActiveAlert(null), 3000);
      }
    });
  }, [reminders]);

  useEffect(() => {
    intervalRef.current = setInterval(checkReminders, 30000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [checkReminders]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const task = tasks.find(t => t.id === newReminder.taskId);
    if (task) {
      addReminder(
        newReminder.name.trim() || `${task.title} Reminder`,
        task.id,
        task.title,
        task.teamId,
        newReminder.sound,
        newReminder.interval,
        newReminder.alertTime
      );
      setNewReminder({ name: '', taskId: '', sound: 'chime', interval: 'daily', alertTime: '09:00' });
      setShowAdd(false);
    }
  };

  const startEditingReminder = (reminder: Reminder) => {
    setEditingReminderId(reminder.id);
    setEditReminderForm({
      name: reminder.name,
      sound: reminder.sound,
      interval: reminder.interval,
      alertTime: reminder.alertTime,
    });
  };

  const saveReminderChanges = () => {
    if (!editingReminderId) return;
    updateReminder(editingReminderId, {
      name: editReminderForm.name.trim() || 'Task Reminder',
      sound: editReminderForm.sound,
      interval: editReminderForm.interval,
      alertTime: editReminderForm.alertTime,
    });
    setEditingReminderId(null);
  };

  const handlePreviewSound = (soundName: string) => {
    playSound(soundName);
  };

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">Reminders</h1>
          <p className="text-gray-500 text-sm mt-1">Manage alerts for your pending tasks</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-200 hover:shadow-xl transition-all"
        >
          <Plus size={16} /> Add Reminder
        </button>
      </div>

      {/* Reminders List */}
      {reminders.length === 0 ? (
        <div className="text-center py-20">
          <Bell size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-bold text-gray-400">No reminders set</h3>
          <p className="text-sm text-gray-400 mt-1">Add reminders to stay on top of your tasks</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reminders.map(reminder => {
            const team = teams.find(t => t.id === reminder.teamId);
            const soundInfo = SOUND_OPTIONS.find(s => s.value === reminder.sound);
            const intervalInfo = INTERVAL_OPTIONS.find(i => i.value === reminder.interval);
            const isAlerting = activeAlert === reminder.id;

            return (
              <div
                key={reminder.id}
                className={`bg-white rounded-2xl border p-5 shadow-sm transition-all duration-200 ${
                  isAlerting
                    ? 'border-orange-400 shadow-lg shadow-orange-100 ring-2 ring-orange-300 animate-pulse'
                    : reminder.enabled
                      ? 'border-blue-100 hover:shadow-md'
                      : 'border-gray-100 opacity-60'
                }`}
              >
                <div className="flex items-start gap-4">
                  {/* Bell Icon */}
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    isAlerting
                      ? 'bg-orange-100 text-orange-600'
                      : reminder.enabled
                        ? 'bg-blue-50 text-blue-600'
                        : 'bg-gray-50 text-gray-400'
                  }`}>
                    <Bell size={20} className={isAlerting ? 'animate-bounce' : ''} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-900 truncate">{reminder.name}</h3>
                    <p className="text-xs text-gray-500 mt-0.5 truncate">Task: {reminder.taskTitle}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-gray-500">
                      <span className="font-semibold text-gray-600">{team?.name}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Volume2 size={11} /> {soundInfo?.label || reminder.sound}
                      </span>
                      <span>•</span>
                      <span>{intervalInfo?.label || reminder.interval}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-semibold text-blue-600">
                        <Clock size={11} /> {formatTime12h(reminder.alertTime)}
                      </span>
                    </div>

                    {/* Sound Changer */}
                    {editingSound === reminder.id && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-xl">
                        <p className="text-xs font-semibold text-gray-600 mb-2">Choose Sound:</p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {SOUND_OPTIONS.map(sound => (
                            <button
                              key={sound.value}
                              onClick={() => { updateReminderSound(reminder.id, sound.value); handlePreviewSound(sound.value); setEditingSound(null); }}
                              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                                reminder.sound === sound.value
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-white border border-gray-200 text-gray-600 hover:border-blue-300'
                              }`}
                            >
                              {sound.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {editingReminderId === reminder.id && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-xl space-y-2">
                        <input
                          type="text"
                          value={editReminderForm.name}
                          onChange={e => setEditReminderForm({ ...editReminderForm, name: e.target.value })}
                          className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xs"
                          placeholder="Reminder name"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="time"
                            value={editReminderForm.alertTime}
                            onChange={e => setEditReminderForm({ ...editReminderForm, alertTime: e.target.value })}
                            className="px-3 py-2 rounded-lg border border-gray-200 text-xs"
                          />
                          <select
                            value={editReminderForm.interval}
                            onChange={e => setEditReminderForm({ ...editReminderForm, interval: e.target.value })}
                            className="px-3 py-2 rounded-lg border border-gray-200 text-xs"
                          >
                            {INTERVAL_OPTIONS.map(i => (
                              <option key={i.value} value={i.value}>{i.label}</option>
                            ))}
                          </select>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {SOUND_OPTIONS.map(sound => (
                            <button
                              key={sound.value}
                              onClick={() => {
                                setEditReminderForm({ ...editReminderForm, sound: sound.value });
                                handlePreviewSound(sound.value);
                              }}
                              className={`px-2 py-1 text-[10px] font-semibold rounded-lg ${
                                editReminderForm.sound === sound.value ? 'bg-blue-600 text-white' : 'bg-white border border-gray-200'
                              }`}
                            >
                              {sound.label}
                            </button>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <button onClick={saveReminderChanges} className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg">
                            Save
                          </button>
                          <button onClick={() => setEditingReminderId(null)} className="px-3 py-1.5 text-xs font-semibold bg-gray-200 text-gray-700 rounded-lg">
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => handlePreviewSound(reminder.sound)}
                      className="p-2 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-500 transition-colors"
                      title="Preview sound"
                    >
                      <Play size={14} />
                    </button>
                    <button
                      onClick={() => setEditingSound(editingSound === reminder.id ? null : reminder.id)}
                      className="p-2 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-500 transition-colors"
                      title="Change sound"
                    >
                      <Volume2 size={14} />
                    </button>
                    <button
                      onClick={() => startEditingReminder(reminder)}
                      className="p-2 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-500 transition-colors"
                      title="Edit reminder"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={() => toggleReminder(reminder.id)}
                      className="text-gray-500 hover:text-blue-600 transition-colors"
                      title={reminder.enabled ? 'Disable' : 'Enable'}
                    >
                      {reminder.enabled ? (
                        <ToggleRight size={28} className="text-blue-600" />
                      ) : (
                        <ToggleLeft size={28} className="text-gray-300" />
                      )}
                    </button>
                    <button
                      onClick={() => deleteReminder(reminder.id)}
                      className="p-2 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Reminder Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowAdd(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Add Reminder</h3>
              <button onClick={() => setShowAdd(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <X size={18} className="text-gray-400" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Reminder Name</label>
                <input
                  type="text"
                  value={newReminder.name}
                  onChange={e => setNewReminder({ ...newReminder, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  placeholder="e.g. Evening progress check"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Select Task</label>
                <select
                  value={newReminder.taskId}
                  onChange={e => setNewReminder({ ...newReminder, taskId: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  required
                >
                  <option value="">Choose a task...</option>
                  {myTasks.map(t => (
                    <option key={t.id} value={t.id}>{t.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Alert Time</label>
                <input
                  type="time"
                  value={newReminder.alertTime}
                  onChange={e => setNewReminder({ ...newReminder, alertTime: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  required
                />
                <p className="text-xs text-gray-400 mt-1">Set the exact time you want to be reminded (e.g. 6:00 PM)</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Sound</label>
                <div className="grid grid-cols-2 gap-2">
                  {SOUND_OPTIONS.map(sound => (
                    <button
                      key={sound.value}
                      type="button"
                      onClick={() => {
                        setNewReminder({ ...newReminder, sound: sound.value });
                        handlePreviewSound(sound.value);
                      }}
                      className={`flex items-center justify-between px-3 py-2 text-sm font-semibold rounded-xl transition-colors ${
                        newReminder.sound === sound.value
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'bg-gray-50 border border-gray-200 text-gray-600 hover:border-blue-300'
                      }`}
                    >
                      <span>{sound.label}</span>
                      <Play size={10} className={newReminder.sound === sound.value ? 'text-white/80' : 'text-gray-400'} />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Frequency</label>
                <select
                  value={newReminder.interval}
                  onChange={e => setNewReminder({ ...newReminder, interval: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                >
                  {INTERVAL_OPTIONS.map(i => (
                    <option key={i.value} value={i.value}>{i.label}</option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-xl shadow-lg shadow-blue-200 text-sm"
              >
                Set Reminder
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
