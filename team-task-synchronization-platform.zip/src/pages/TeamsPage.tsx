import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Info, Users, MessageCircle, Trash2, LogOut as LeaveIcon, X, UserPlus, Check, Search, SendHorizontal, CheckCircle2, XCircle } from 'lucide-react';
import { useStore } from '../store';

export default function TeamsPage() {
  const {
    currentUser,
    teams,
    allTeams,
    joinRequests,
    createTeam,
    addMembersToTeam,
    searchTeams,
    requestJoinTeam,
    reviewJoinRequest,
    deleteTeam,
    leaveTeam,
    allUsers,
    findUsers,
    seedTestProfiles,
  } = useStore();
  const [showCreate, setShowCreate] = useState(false);
  const [showInfo, setShowInfo] = useState<string | null>(null);
  const [showAddMembersTeamId, setShowAddMembersTeamId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [createMemberSearch, setCreateMemberSearch] = useState('');
  const [createSearchedUsers, setCreateSearchedUsers] = useState<typeof allUsers>([]);
  const [isSearchingCreateUsers, setIsSearchingCreateUsers] = useState(false);
  const [memberSearch, setMemberSearch] = useState('');
  const [searchedUsers, setSearchedUsers] = useState<typeof allUsers>([]);
  const [isSearchingUsers, setIsSearchingUsers] = useState(false);
  const [selectedAddedMembers, setSelectedAddedMembers] = useState<string[]>([]);
  const [showSeedNotice, setShowSeedNotice] = useState(false);
  const [teamSearch, setTeamSearch] = useState('');
  const [searchedTeams, setSearchedTeams] = useState(allTeams);
  const [isSearchingTeams, setIsSearchingTeams] = useState(false);
  const [joinStatus, setJoinStatus] = useState<string | null>(null);

  const myTeams = teams.filter(t => t.members.includes(currentUser.id));
  const pendingLeaderRequests = joinRequests.filter((request) => {
    if (request.status !== 'pending') return false;
    const team = allTeams.find((entry) => entry.id === request.teamId);
    if (!team) return false;
    return team.leaderId === currentUser.id || team.createdBy === currentUser.id;
  });
  const activeTeam = showAddMembersTeamId ? teams.find((team) => team.id === showAddMembersTeamId) : null;
  const teamEligibleUsers = activeTeam
    ? searchedUsers.filter((user) => user.id !== currentUser.id && !activeTeam.members.includes(user.id))
    : [];
  const createEligibleUsers = createSearchedUsers.filter((user) => user.id !== currentUser.id);
  const teamSearchResults = searchedTeams.filter((team) => !team.members.includes(currentUser.id));

  const toggleMember = (userId: string) => {
    setSelectedMembers(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  const toggleAddedMember = (userId: string) => {
    setSelectedAddedMembers(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  useEffect(() => {
    let cancelled = false;

    const runSearch = async () => {
      setIsSearchingUsers(true);
      const users = await findUsers(memberSearch);
      if (!cancelled) {
        setSearchedUsers(users.filter((user) => user.id !== currentUser.id));
        setIsSearchingUsers(false);
      }
    };

    void runSearch();

    return () => {
      cancelled = true;
    };
  }, [memberSearch, currentUser.id, findUsers]);

  useEffect(() => {
    let cancelled = false;

    const runSearch = async () => {
      setIsSearchingCreateUsers(true);
      const users = await findUsers(createMemberSearch);
      if (!cancelled) {
        setCreateSearchedUsers(users.filter((user) => user.id !== currentUser.id));
        setIsSearchingCreateUsers(false);
      }
    };

    void runSearch();

    return () => {
      cancelled = true;
    };
  }, [createMemberSearch, currentUser.id, findUsers]);

  useEffect(() => {
    let cancelled = false;

    const runSearch = async () => {
      setIsSearchingTeams(true);
      const result = await searchTeams(teamSearch);
      if (!cancelled) {
        setSearchedTeams(result);
        setIsSearchingTeams(false);
      }
    };

    void runSearch();

    return () => {
      cancelled = true;
    };
  }, [teamSearch, searchTeams]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      createTeam(newName.trim(), newDesc.trim(), selectedMembers);
      setNewName('');
      setNewDesc('');
      setSelectedMembers([]);
      setCreateMemberSearch('');
      setShowCreate(false);
    }
  };

  const openAddMembersModal = (teamId: string) => {
    setShowAddMembersTeamId(teamId);
    setMemberSearch('');
    setSelectedAddedMembers([]);
  };

  const closeAddMembersModal = () => {
    setShowAddMembersTeamId(null);
    setSelectedAddedMembers([]);
    setMemberSearch('');
  };

  const handleAddMembers = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showAddMembersTeamId || selectedAddedMembers.length === 0) return;
    addMembersToTeam(showAddMembersTeamId, selectedAddedMembers);
    closeAddMembersModal();
  };

  const teamColors = ['from-blue-400 to-blue-600', 'from-orange-400 to-orange-600', 'from-indigo-400 to-indigo-600', 'from-emerald-400 to-emerald-600', 'from-pink-400 to-pink-600'];

  const handleLoadTestProfiles = () => {
    seedTestProfiles();
    setShowSeedNotice(true);
    window.setTimeout(() => setShowSeedNotice(false), 3500);
  };

  const handleSendJoinRequest = async (teamId: string) => {
    const result = await requestJoinTeam(teamId);
    setJoinStatus(result.message);
    window.setTimeout(() => setJoinStatus(null), 3200);
  };

  const handleReviewRequest = async (requestId: string, decision: 'accepted' | 'rejected') => {
    await reviewJoinRequest(requestId, decision);
  };

  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">My Teams</h1>
          <p className="text-gray-500 text-sm mt-1">Manage and access all your project teams</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleLoadTestProfiles}
            className="flex items-center gap-2 px-4 py-2.5 bg-white text-blue-700 border border-blue-200 font-semibold text-sm rounded-xl hover:bg-blue-50 transition-colors"
          >
            <UserPlus size={16} /> Load Test Profiles
          </button>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold text-sm rounded-xl shadow-lg shadow-blue-200 hover:shadow-xl hover:shadow-blue-300 transition-all"
          >
            <Plus size={16} /> Create Team
          </button>
        </div>
      </div>

      {showSeedNotice && (
        <div className="mb-5 rounded-xl border border-blue-100 bg-blue-50 px-4 py-2 text-sm text-blue-700">
          Test users loaded. Open "Test Collaboration Lab" to try chat and task assignment, then use "Add Members" to add more seeded users.
        </div>
      )}

      {joinStatus && (
        <div className="mb-5 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-2 text-sm text-emerald-700">
          {joinStatus}
        </div>
      )}

      <div className="mb-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-gray-100 bg-white p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-gray-900">Find Teams</h2>
            <Search size={14} className="text-gray-400" />
          </div>
          <input
            type="text"
            value={teamSearch}
            onChange={(e) => setTeamSearch(e.target.value)}
            className="mb-3 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            placeholder="Search teams by name or description"
          />
          <div className="max-h-56 space-y-2 overflow-y-auto">
            {isSearchingTeams && <p className="text-xs text-gray-500">Searching teams...</p>}
            {!isSearchingTeams && teamSearchResults.length === 0 && (
              <p className="text-xs text-gray-500">No joinable teams found.</p>
            )}
            {!isSearchingTeams && teamSearchResults.map((team) => {
              const hasPending = joinRequests.some(
                (request) => request.teamId === team.id && request.requesterId === currentUser.id && request.status === 'pending'
              );
              return (
                <div key={team.id} className="rounded-xl border border-gray-100 bg-gray-50 p-3">
                  <p className="text-sm font-semibold text-gray-900">{team.name}</p>
                  <p className="line-clamp-1 text-xs text-gray-500">{team.description}</p>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[11px] text-gray-500">{team.members.length} members</span>
                    <button
                      type="button"
                      onClick={() => void handleSendJoinRequest(team.id)}
                      disabled={hasPending}
                      className="inline-flex items-center gap-1 rounded-lg bg-blue-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <SendHorizontal size={12} />
                      {hasPending ? 'Pending' : 'Request Join'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-4">
          <h2 className="mb-3 text-sm font-bold text-gray-900">Join Requests</h2>
          <div className="max-h-56 space-y-2 overflow-y-auto">
            {pendingLeaderRequests.length === 0 && (
              <p className="text-xs text-gray-500">No pending requests for your teams.</p>
            )}
            {pendingLeaderRequests.map((request) => {
              const requester = allUsers.find((user) => user.id === request.requesterId);
              const team = allTeams.find((entry) => entry.id === request.teamId);
              return (
                <div key={request.id} className="rounded-xl border border-gray-100 bg-gray-50 p-3">
                  <p className="text-xs font-semibold text-gray-900">{requester?.name || 'Unknown user'}</p>
                  <p className="text-[11px] text-gray-500">{requester?.email || 'No email available'}</p>
                  <p className="mt-1 text-[11px] text-gray-600">wants to join {team?.name || 'this team'}</p>
                  <div className="mt-2 flex gap-2">
                    <button
                      type="button"
                      onClick={() => void handleReviewRequest(request.id, 'accepted')}
                      className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-emerald-700"
                    >
                      <CheckCircle2 size={12} /> Accept
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleReviewRequest(request.id, 'rejected')}
                      className="inline-flex items-center gap-1 rounded-lg bg-gray-200 px-2.5 py-1.5 text-[11px] font-semibold text-gray-700 hover:bg-gray-300"
                    >
                      <XCircle size={12} /> Reject
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Team Grid */}
      {myTeams.length === 0 ? (
        <div className="text-center py-20">
          <Users size={48} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-bold text-gray-400">No teams yet</h3>
          <p className="text-sm text-gray-400 mt-1">Create or join a team to get started</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {myTeams.map((team, idx) => {
            const memberNames = team.members.map(id => allUsers.find(u => u.id === id)?.name || 'Unknown');
            const isCreator = team.createdBy === currentUser.id;
            const canManageMembers = isCreator || team.leaderId === currentUser.id;
            const colorClass = teamColors[idx % teamColors.length];

            return (
              <div key={team.id} className="group relative bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden">
                {/* Color Top Bar */}
                <div className={`h-2 bg-gradient-to-r ${colorClass}`} />

                <div className="p-5">
                  {/* Team Icon + Name */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorClass} flex items-center justify-center text-white font-bold text-lg shadow-md`}>
                        {team.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 text-base leading-tight">{team.name}</h3>
                        <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{team.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Members */}
                  <div className="flex items-center gap-1 mb-4">
                    <div className="flex -space-x-2">
                      {memberNames.slice(0, 4).map((name, i) => (
                        <div
                          key={i}
                          className="w-7 h-7 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-blue-700"
                          title={name}
                        >
                          {name.split(' ').map(n => n[0]).join('')}
                        </div>
                      ))}
                    </div>
                    <span className="text-xs text-gray-400 ml-2">{team.members.length} member{team.members.length > 1 ? 's' : ''}</span>
                  </div>

                  {/* Actions Row */}
                  <div className="flex items-center gap-2">
                    <Link
                      to={`/teams/${team.id}/chat`}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs rounded-lg transition-colors"
                    >
                      <MessageCircle size={14} /> Open Chat
                    </Link>
                    <button
                      onClick={() => setShowInfo(showInfo === team.id ? null : team.id)}
                      className="p-2 rounded-lg bg-gray-50 hover:bg-gray-100 text-gray-500 transition-colors"
                      title="Team Info"
                    >
                      <Info size={14} />
                    </button>
                  </div>

                  {/* Info Dropdown */}
                  {showInfo === team.id && (
                    <div className="mt-3 p-4 bg-gray-50 rounded-xl border border-gray-100 animate-in fade-in">
                      <p className="text-sm text-gray-700 mb-3">{team.description}</p>
                      <p className="text-xs text-gray-500 mb-3">
                        <strong>Leader:</strong> {allUsers.find(u => u.id === team.leaderId)?.name}
                      </p>
                      <p className="text-xs text-gray-500 mb-3">
                        <strong>Members:</strong> {memberNames.join(', ')}
                      </p>
                        <div className="flex flex-wrap gap-2">
                          {canManageMembers && (
                            <button
                              onClick={() => openAddMembersModal(team.id)}
                              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                            >
                              <UserPlus size={12} /> Add Members
                            </button>
                          )}
                        {!isCreator && (
                          <button
                            onClick={() => leaveTeam(team.id)}
                            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-orange-600 bg-orange-50 hover:bg-orange-100 rounded-lg transition-colors"
                          >
                            <LeaveIcon size={12} /> Leave Team
                          </button>
                        )}
                        {isCreator && (
                          <button
                            onClick={() => deleteTeam(team.id)}
                            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                          >
                            <Trash2 size={12} /> Delete Team
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Members Modal */}
      {showAddMembersTeamId && activeTeam && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={closeAddMembersModal}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Add Members to {activeTeam.name}</h3>
              <button onClick={closeAddMembersModal} className="p-1 rounded-lg hover:bg-gray-100">
                <X size={18} className="text-gray-400" />
              </button>
            </div>

            <form onSubmit={handleAddMembers} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Find Users</label>
                <input
                  type="text"
                  value={memberSearch}
                  onChange={e => setMemberSearch(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  placeholder="Search by name or email"
                />
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto border border-gray-100 rounded-xl p-3 bg-gray-50">
                {isSearchingUsers && <p className="text-xs text-gray-500">Searching users...</p>}
                {!isSearchingUsers && teamEligibleUsers.length === 0 && (
                  <p className="text-xs text-gray-500">No users found. Ask teammates to create an account first.</p>
                )}
                {!isSearchingUsers && teamEligibleUsers.map(user => {
                  const isSelected = selectedAddedMembers.includes(user.id);
                  return (
                    <button
                      key={user.id}
                      type="button"
                      onClick={() => toggleAddedMember(user.id)}
                      className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all ${
                        isSelected
                          ? 'bg-blue-50 border border-blue-200 shadow-sm'
                          : 'bg-white border border-gray-100 hover:border-blue-200'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        isSelected
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-500'
                      }`}>
                        {user.avatar}
                      </div>
                      <div className="text-left flex-1">
                        <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                        <p className="text-[10px] text-gray-400">{user.email}</p>
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center">
                          <Check size={12} className="text-white" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              <button
                type="submit"
                disabled={selectedAddedMembers.length === 0}
                className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-xl shadow-lg shadow-blue-200 hover:shadow-xl transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Selected Members
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Create Team Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCreate(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-gray-900">Create New Team</h3>
              <button onClick={() => { setShowCreate(false); setSelectedMembers([]); setCreateMemberSearch(''); }} className="p-1 rounded-lg hover:bg-gray-100">
                <X size={18} className="text-gray-400" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Team Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  placeholder="e.g. Capstone Project Alpha"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
                <textarea
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm resize-none"
                  rows={3}
                  placeholder="Describe what this team is working on..."
                />
              </div>

              {/* Add Members */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <UserPlus size={14} /> Add Members
                  </span>
                </label>
                <p className="text-xs text-gray-400 mb-2">You will be added automatically as the team leader. Select other members to add:</p>
                <input
                  type="text"
                  value={createMemberSearch}
                  onChange={e => setCreateMemberSearch(e.target.value)}
                  className="w-full mb-2 px-3 py-2 rounded-lg border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none text-sm"
                  placeholder="Search users by name or email"
                />
                <div className="space-y-2 max-h-48 overflow-y-auto border border-gray-100 rounded-xl p-3 bg-gray-50">
                  {isSearchingCreateUsers && <p className="text-xs text-gray-500">Searching users...</p>}
                  {!isSearchingCreateUsers && createEligibleUsers.length === 0 && (
                    <p className="text-xs text-gray-500">No accounts found for this search.</p>
                  )}
                  {!isSearchingCreateUsers && createEligibleUsers.map(user => {
                    const isSelected = selectedMembers.includes(user.id);
                    return (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => toggleMember(user.id)}
                        className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all ${
                          isSelected
                            ? 'bg-blue-50 border border-blue-200 shadow-sm'
                            : 'bg-white border border-gray-100 hover:border-blue-200'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                          isSelected
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-500'
                        }`}>
                          {user.avatar}
                        </div>
                        <div className="text-left flex-1">
                          <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                          <p className="text-[10px] text-gray-400">{user.email}</p>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center">
                            <Check size={12} className="text-white" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
                {selectedMembers.length > 0 && (
                  <p className="text-xs text-blue-600 font-semibold mt-2">
                    {selectedMembers.length} member{selectedMembers.length > 1 ? 's' : ''} selected
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-xl shadow-lg shadow-blue-200 hover:shadow-xl transition-all text-sm"
              >
                Create Team
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
