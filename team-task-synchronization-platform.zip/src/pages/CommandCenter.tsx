import { ExternalLink, Zap } from 'lucide-react';

const TOOLS = [
  {
    name: 'ChatGPT',
    description: 'AI assistant for brainstorming, writing, and problem solving',
    url: 'https://chatgpt.com',
    icon: '🤖',
    color: 'from-green-400 to-emerald-600',
    bgLight: 'bg-green-50',
  },
  {
    name: 'Perplexity',
    description: 'AI-powered research and answer engine',
    url: 'https://perplexity.ai',
    icon: '🔍',
    color: 'from-blue-400 to-cyan-600',
    bgLight: 'bg-blue-50',
  },
  {
    name: 'Genspark AI',
    description: 'AI-powered agent for research and content generation',
    url: 'https://www.genspark.ai',
    icon: '✨',
    color: 'from-purple-400 to-violet-600',
    bgLight: 'bg-purple-50',
  },
  {
    name: 'GitHub',
    description: 'Code hosting, version control, and collaboration',
    url: 'https://github.com',
    icon: '🐙',
    color: 'from-gray-600 to-gray-900',
    bgLight: 'bg-gray-50',
  },
  {
    name: 'Eraser.io',
    description: 'Collaborative diagrams, docs, and whiteboarding',
    url: 'https://www.eraser.io',
    icon: '📐',
    color: 'from-indigo-400 to-indigo-600',
    bgLight: 'bg-indigo-50',
  },
  {
    name: 'n8n',
    description: 'Workflow automation and integration platform',
    url: 'https://n8n.io',
    icon: '⚡',
    color: 'from-orange-400 to-red-500',
    bgLight: 'bg-orange-50',
  },
  {
    name: 'LibreOffice Online',
    description: 'Free and open-source office suite',
    url: 'https://www.libreoffice.org',
    icon: '📄',
    color: 'from-green-500 to-green-700',
    bgLight: 'bg-green-50',
  },
  {
    name: 'Microsoft Office',
    description: 'Word, Excel, PowerPoint and more online',
    url: 'https://www.office.com',
    icon: '📊',
    color: 'from-orange-500 to-red-600',
    bgLight: 'bg-orange-50',
  },
];

export default function CommandCenter() {
  return (
    <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center shadow-md shadow-orange-200">
            <Zap size={20} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">Command Center</h1>
            <p className="text-gray-500 text-sm">Quick access to all the tools your team needs</p>
          </div>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {TOOLS.map(tool => (
          <a
            key={tool.name}
            href={tool.url}
            target="_blank"
            rel="noopener"
            className="group bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-12 h-12 rounded-xl ${tool.bgLight} flex items-center justify-center text-2xl`}>
                {tool.icon}
              </div>
              <ExternalLink size={14} className="text-gray-300 group-hover:text-blue-500 transition-colors mt-1" />
            </div>
            <h3 className="font-bold text-gray-900 mb-1">{tool.name}</h3>
            <p className="text-xs text-gray-500 leading-relaxed">{tool.description}</p>
            <div className={`mt-3 h-1 rounded-full bg-gradient-to-r ${tool.color} w-0 group-hover:w-full transition-all duration-500`} />
          </a>
        ))}
      </div>
    </div>
  );
}
