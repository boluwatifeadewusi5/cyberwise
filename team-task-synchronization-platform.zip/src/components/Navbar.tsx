import { Link, useLocation } from 'react-router-dom';
import { Users, CheckSquare, Bell, LayoutDashboard, LogOut, Zap } from 'lucide-react';
import { useStore } from '../store';

export default function Navbar() {
  const location = useLocation();
  const { currentUser, logout } = useStore();

  const links = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/teams', label: 'Teams', icon: Users },
    { to: '/tasks', label: 'Tasks', icon: CheckSquare },
    { to: '/reminders', label: 'Reminders', icon: Bell },
    { to: '/command-center', label: 'Tools', icon: Zap },
  ];

  return (
    <nav className="bg-white border-b border-blue-100 shadow-sm sticky top-0 z-50">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/dashboard" className="flex items-center gap-2.5 flex-shrink-0">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-md shadow-blue-200">
              <span className="text-white font-black text-sm tracking-tight">M</span>
            </div>
            <span className="text-xl font-extrabold tracking-tight text-gray-900">Micah</span>
          </Link>

          {/* Nav Links */}
          <div className="flex items-center gap-1">
            {links.map(link => {
              const isActive = location.pathname === link.to || location.pathname.startsWith(link.to + '/');
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <link.icon size={18} strokeWidth={isActive ? 2.5 : 2} />
                  <span className="hidden md:inline">{link.label}</span>
                </Link>
              );
            })}
          </div>

          {/* User */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-xs font-bold shadow">
                {currentUser.avatar}
              </div>
              <span className="text-sm font-semibold text-gray-700">{currentUser.name.split(' ')[0]}</span>
            </div>
            <button
              onClick={logout}
              className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all"
              title="Logout"
            >
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
