# Micah Backend Setup (Supabase)

## 1. Configure Env
Copy `.env.example` to `.env` and set your Supabase project values.

## 2. Create Workspace Table
Run this SQL in Supabase SQL editor:

```sql
create table if not exists public.micah_workspaces (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.micah_workspaces enable row level security;

create policy "workspace_select_own"
on public.micah_workspaces
for select
to authenticated
using (auth.uid() = user_id);

create policy "workspace_upsert_own"
on public.micah_workspaces
for all
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
```

## 3. Create Profiles Table
This stores user profile data used in member pickers and team creation.

```sql
create table if not exists public.micah_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null,
  avatar text not null,
  updated_at timestamptz not null default now()
);

create unique index if not exists micah_profiles_email_unique
on public.micah_profiles (lower(email));

create index if not exists micah_profiles_name_email_search_idx
on public.micah_profiles (name, email);

alter table public.micah_profiles enable row level security;

create policy "profiles_select_all_authenticated"
on public.micah_profiles
for select
to authenticated
using (true);

create policy "profiles_upsert_own"
on public.micah_profiles
for all
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);
```

## 4. Create Chat Messages Table
This enables real-time chat persistence between signed-in users.

```sql
create table if not exists public.micah_messages (
  id text primary key,
  team_id text not null,
  sender_id uuid not null references auth.users(id) on delete cascade,
  sender_name text not null,
  content text not null,
  timestamp timestamptz not null,
  is_task_assignment boolean not null default false,
  task_id text null
);

alter table public.micah_messages enable row level security;

create policy "messages_select_all_authenticated"
on public.micah_messages
for select
to authenticated
using (true);

create policy "messages_insert_authenticated"
on public.micah_messages
for insert
to authenticated
with check (auth.uid() = sender_id);
```

## 5. Authentication
Enable Email/Password auth in Supabase Auth providers.

## 6. Create Teams + Membership Tables
This stores a global directory of teams and membership for search/join flows.

```sql
create table if not exists public.micah_teams (
  id text primary key,
  name text not null,
  description text not null default '',
  created_by uuid not null references auth.users(id) on delete cascade,
  leader_id uuid not null references auth.users(id) on delete cascade,
  color text not null default '#3B82F6',
  created_at timestamptz not null default now()
);

create table if not exists public.micah_team_members (
  team_id text not null references public.micah_teams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (team_id, user_id)
);

alter table public.micah_teams enable row level security;
alter table public.micah_team_members enable row level security;

create policy "teams_select_authenticated"
on public.micah_teams
for select
to authenticated
using (true);

create policy "teams_insert_owner"
on public.micah_teams
for insert
to authenticated
with check (auth.uid() = created_by);

create policy "teams_update_leader"
on public.micah_teams
for update
to authenticated
using (auth.uid() = leader_id)
with check (auth.uid() = leader_id);

create policy "team_members_select_authenticated"
on public.micah_team_members
for select
to authenticated
using (true);

create policy "team_members_insert_authenticated"
on public.micah_team_members
for insert
to authenticated
with check (true);
```

## 7. Create Team Join Request Table

```sql
create table if not exists public.micah_join_requests (
  id text primary key,
  team_id text not null references public.micah_teams(id) on delete cascade,
  requester_id uuid not null references auth.users(id) on delete cascade,
  status text not null check (status in ('pending', 'accepted', 'rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id) on delete set null
);

create unique index if not exists micah_join_requests_pending_unique
on public.micah_join_requests (team_id, requester_id)
where status = 'pending';

alter table public.micah_join_requests enable row level security;

create policy "join_requests_select_authenticated"
on public.micah_join_requests
for select
to authenticated
using (true);

create policy "join_requests_insert_requester"
on public.micah_join_requests
for insert
to authenticated
with check (auth.uid() = requester_id);

create policy "join_requests_update_authenticated"
on public.micah_join_requests
for update
to authenticated
using (true)
with check (true);
```

## 8. Realtime Chat
Enable Realtime for `public.micah_messages` in Supabase.

Micah chat uses:
- Supabase broadcast channel for low-latency fanout.
- `micah_messages` inserts + realtime DB subscriptions for persistence and cross-device sync.
- Browser `BroadcastChannel` fallback when env values are missing.

